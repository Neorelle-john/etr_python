# ETR E-Commerce Project

A Flask-based e-commerce application with customer registration and login functionality.

## Features

- **Customer Registration**: Users can create accounts with personal information
- **Customer Login**: Secure authentication system
- **User Profile**: View customer profile information
- **Session Management**: Remember me functionality and secure logout

## Setup Instructions

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the Application**
   ```bash
   python app.py
   ```

3. **Access the Application**
   - Open your browser and navigate to `http://localhost:5000`
   - Register a new account or login with existing credentials

## Project Structure

```
etr_ecommerce/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── templates/            # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── register.html
│   ├── login.html
│   └── profile.html
└── static/              # Static files (CSS, JS, images)
```

## Database

The application uses SQLite by default (can be configured for other databases via environment variables).

The database file `etr_ecommerce.db` will be created automatically on first run.

## Environment Variables (Optional)

Create a `.env` file to configure:

```
SECRET_KEY=your-secret-key-here
DATABASE_URL=sqlite:///etr_ecommerce.db
```

## Customer Model

The Customer model includes:
- Username (unique)
- Email (unique)
- Password (hashed)
- First Name, Last Name
- Phone, Address, City, State, ZIP, Country
- Account creation timestamp
- Active status

## Security Features

- Password hashing using Werkzeug
- Session management with Flask-Login
- CSRF protection (via Flask's secret key)
- Input validation

## Next Steps

Future enhancements can include:
- Product catalog
- Shopping cart
- Order management
- Payment integration
- Admin panel

