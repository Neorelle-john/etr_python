# Product Image Naming Guide

All product images should be placed in: `static/images/products/`

## Image File Names Required:

### ELECTRONICS (6 images)
1. `headset.jpg` - Wireless Bluetooth Headphones
2. `smartP.jpg` - Smartphone 128GB
3. `wmouse.jpg` - Wireless Mouse
4. `keyb.jpg` - Gaming Keyboard
5. `smartW.jpg` - Smart Watch Pro
6. `tv.jpg` - 4K Ultra HD TV 55"

### FOOTWEAR (6 images)
1. `nikeS.jpg` - Running Shoes
2. `Sneak.jpg` - Casual Sneakers
3. `lshoes.jpg` - Leather Dress Shoes
4. `hikingSh.jpg` - Hiking Boots
5. `sandal.jpg` - Sandals
6. `lebronS.jpg` - Basketball Shoes

### CLOTHING (6 images)
1. `tshirt.jpg` - Cotton T-Shirt
2. `jeans.jpg` - Denim Jeans
3. `hood.jpg` - Hooded Sweatshirt
4. `poloS.jpg` - Polo Shirt
5. `summerD.jpg` - Summer Dress
6. `letherJack.jpg` - Leather Jacket

### ACCESSORIES (6 images)
1. `laptopB.jpg` - Laptop Backpack
2. `walletL.jpg` - Leather Wallet
3. `tumbler.jpg` - Stainless Steel Water Bottle
4. `Iglases.jpg` - Sunglasses
5. `belts.jpg` - Leather Belt
6. `case.jpg` - Smartphone Case

### HOME & KITCHEN (6 images)
1. `CM.jpg` - Coffee Maker
2. `airf.jpg` - Air Fryer
3. `blender.jpg` - Blender
4. `dinnerSet.jpg` - Dinnerware Set
5. `cookset.jpg` - Cookware Set
6. `KT.jpg` - Stand Mixer

### SPORTS & FITNESS (6 images)
1. `yogaM.jpg` - Yoga Mat
2. `dumpbell.jpg` - Dumbbell Set
3. `resistance.jpg` - Resistance Bands Set
4. `jumprope.jpg` - Jump Rope
5. `roler.jpg` - Foam Roller
6. `bike.jpg` - Exercise Bike

## Total: 36 image files

All images should be in JPG format and placed in: `static/images/products/`

The code has been updated to use these local image paths instead of external URLs.

