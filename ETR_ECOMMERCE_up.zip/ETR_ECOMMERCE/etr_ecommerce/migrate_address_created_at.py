"""
Fix missing columns in address table:
- created_at
- is_default
"""

import sqlite3
import os

DB_PATH = "instance/etr_ecommerce.db"

if not os.path.exists(DB_PATH):
    print(f"[ERROR] Database not found: {DB_PATH}")
    exit(1)

conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

try:
    # Confirm address table exists
    cursor.execute("""
        SELECT name FROM sqlite_master
        WHERE type='table' AND name='address'
    """)
    if not cursor.fetchone():
        print("[ERROR] address table does not exist")
        exit(1)

    # Get current columns
    cursor.execute("PRAGMA table_info(address)")
    columns = [row[1] for row in cursor.fetchall()]

    # Add created_at
    if "created_at" not in columns:
        print("Adding created_at...")
        cursor.execute(
            "ALTER TABLE address ADD COLUMN created_at DATETIME"
        )
        print("[OK] created_at added")
    else:
        print("[OK] created_at already exists")

    # Add is_default
    if "is_default" not in columns:
        print("Adding is_default...")
        cursor.execute(
            "ALTER TABLE address ADD COLUMN is_default BOOLEAN DEFAULT 0"
        )
        print("[OK] is_default added")
    else:
        print("[OK] is_default already exists")

    conn.commit()
    print("\n[SUCCESS] Address table fixed")

except Exception as e:
    conn.rollback()
    print("[ERROR]", e)

finally:
    conn.close()
