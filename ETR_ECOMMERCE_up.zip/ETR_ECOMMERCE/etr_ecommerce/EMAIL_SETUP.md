# Email Configuration Guide

## Setting Up Email for Password Reset and Notifications

The application now supports email functionality for:
- Password reset requests
- Order confirmations
- Order status updates

### Configuration Options

#### Option 1: Gmail (Recommended for Development)

1. **Enable 2-Factor Authentication** on your Gmail account
2. **Generate an App Password**:
   - Go to Google Account → Security → 2-Step Verification → App passwords
   - Generate a password for "Mail"
   - Copy the 16-character password

3. **Set Environment Variables**:

Create a `.env` file in your project root:

```env
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-16-char-app-password
MAIL_DEFAULT_SENDER=your-email@gmail.com
MAIL_SUPPRESS_SEND=False
```

#### Option 2: Other SMTP Servers

For other email providers (Outlook, Yahoo, custom SMTP):

```env
MAIL_SERVER=smtp.your-provider.com
MAIL_PORT=587  # or 465 for SSL
MAIL_USE_TLS=True  # or False for SSL
MAIL_USERNAME=your-email@domain.com
MAIL_PASSWORD=your-password
MAIL_DEFAULT_SENDER=your-email@domain.com
MAIL_SUPPRESS_SEND=False
```

#### Option 3: Disable Email (Development Only)

To disable actual email sending (useful for testing):

```env
MAIL_SUPPRESS_SEND=True
```

When `MAIL_SUPPRESS_SEND=True`, the application will:
- Process all email requests
- Show success messages to users
- Not actually send emails
- Useful for development/testing without email setup

### Testing Email Configuration

1. Set up your `.env` file with email credentials
2. Restart the Flask application
3. Try the "Forgot Password" feature
4. Check your email inbox (and spam folder)

### Important Notes

- **Security**: Never commit `.env` file to version control
- **Production**: Use a dedicated email service (SendGrid, Mailgun, AWS SES) for production
- **Rate Limits**: Be aware of email sending rate limits from your provider
- **Spam**: Make sure your email domain is properly configured to avoid spam filters

### Troubleshooting

**Email not sending?**
- Check your email credentials in `.env`
- Verify SMTP server settings
- Check firewall/network restrictions
- Check application logs for error messages

**Gmail "Less secure app" error?**
- Use App Passwords instead of regular password
- Ensure 2-Factor Authentication is enabled

**Emails going to spam?**
- Configure SPF, DKIM, and DMARC records for your domain
- Use a dedicated email service for production

