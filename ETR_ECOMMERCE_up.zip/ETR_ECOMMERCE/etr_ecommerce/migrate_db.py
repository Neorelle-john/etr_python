"""
Database migration script to add new columns to Customer table:
- gender
- date_of_birth
- profile_picture_url
"""
import sqlite3
import os

# Database file path (Flask-SQLAlchemy creates it in instance folder by default)
db_path = 'instance/etr_ecommerce.db'

if not os.path.exists(db_path):
    print(f"Database file {db_path} not found. Creating new database...")
    print("Please run the Flask app first to create the database, then run this migration.")
    exit(1)

# Connect to database
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

try:
    # Check if columns already exist
    cursor.execute("PRAGMA table_info(customer)")
    columns = [row[1] for row in cursor.fetchall()]
    
    # Add gender column if it doesn't exist
    if 'gender' not in columns:
        print("Adding 'gender' column...")
        cursor.execute("ALTER TABLE customer ADD COLUMN gender VARCHAR(10)")
        print("[OK] Added 'gender' column")
    else:
        print("[OK] 'gender' column already exists")
    
    # Add date_of_birth column if it doesn't exist
    if 'date_of_birth' not in columns:
        print("Adding 'date_of_birth' column...")
        cursor.execute("ALTER TABLE customer ADD COLUMN date_of_birth DATE")
        print("[OK] Added 'date_of_birth' column")
    else:
        print("[OK] 'date_of_birth' column already exists")
    
    # Add profile_picture_url column if it doesn't exist
    if 'profile_picture_url' not in columns:
        print("Adding 'profile_picture_url' column...")
        cursor.execute("ALTER TABLE customer ADD COLUMN profile_picture_url VARCHAR(255)")
        print("[OK] Added 'profile_picture_url' column")
    else:
        print("[OK] 'profile_picture_url' column already exists")
    
    # Commit changes
    conn.commit()
    print("\n[SUCCESS] Migration completed successfully!")
    print("You can now restart your Flask application.")
    
except sqlite3.Error as e:
    print(f"\n[ERROR] Error during migration: {e}")
    conn.rollback()
    exit(1)
finally:
    conn.close()

