"""
Migration script to add notification fields to Customer table and create Notification table
Run this script once to update your database schema.
"""
from app import app, db
from sqlalchemy import text

def migrate_database():
    """Add notification columns to Customer table and create Notification table"""
    with app.app_context():
        try:
            # Check if columns already exist
            inspector = db.inspect(db.engine)
            customer_columns = [col['name'] for col in inspector.get_columns('customer')]
            
            # Add email_notifications column if it doesn't exist
            if 'email_notifications' not in customer_columns:
                print("Adding email_notifications column to customer table...")
                db.session.execute(text("ALTER TABLE customer ADD COLUMN email_notifications BOOLEAN DEFAULT 1"))
                db.session.commit()
                print("[OK] Added email_notifications column")
            else:
                print("[OK] email_notifications column already exists")
            
            # Add order_updates column if it doesn't exist
            if 'order_updates' not in customer_columns:
                print("Adding order_updates column to customer table...")
                db.session.execute(text("ALTER TABLE customer ADD COLUMN order_updates BOOLEAN DEFAULT 1"))
                db.session.commit()
                print("[OK] Added order_updates column")
            else:
                print("[OK] order_updates column already exists")
            
            # Create notification table if it doesn't exist
            tables = inspector.get_table_names()
            if 'notification' not in tables:
                print("Creating notification table...")
                db.session.execute(text("""
                    CREATE TABLE notification (
                        id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                        customer_id INTEGER NOT NULL,
                        order_id INTEGER,
                        title VARCHAR(200) NOT NULL,
                        message TEXT NOT NULL,
                        type VARCHAR(50) NOT NULL,
                        is_read BOOLEAN DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY(customer_id) REFERENCES customer (id),
                        FOREIGN KEY(order_id) REFERENCES "order" (id)
                    )
                """))
                db.session.commit()
                print("[OK] Created notification table")
            else:
                print("[OK] notification table already exists")
            
            print("\n[SUCCESS] Migration completed successfully!")
            
        except Exception as e:
            db.session.rollback()
            print(f"[ERROR] Error during migration: {str(e)}")
            raise

if __name__ == '__main__':
    print("Starting database migration...")
    print("=" * 50)
    migrate_database()
    print("=" * 50)
    print("Migration finished!")

