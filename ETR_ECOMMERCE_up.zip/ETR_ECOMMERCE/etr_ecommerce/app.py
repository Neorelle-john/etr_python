from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_mail import Mail, Message
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadSignature
import os
from decimal import Decimal
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from io import BytesIO

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///etr_ecommerce.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads/payments'
app.config['PROFILE_PICTURE_FOLDER'] = 'static/uploads/profiles'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Email configuration
app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
app.config['MAIL_PORT'] = int(os.environ.get('MAIL_PORT', 587))
app.config['MAIL_USE_TLS'] = os.environ.get('MAIL_USE_TLS', 'True').lower() in ['true', 'on', '1']
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', '')
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', '')
app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER', 'noreply@etr-ecommerce.com')
app.config['MAIL_SUPPRESS_SEND'] = os.environ.get('MAIL_SUPPRESS_SEND', 'False').lower() in ['true', 'on', '1']

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please sign in to access this page.'
login_manager.login_message_category = 'info'

mail = Mail(app)

# Password reset serializer
password_reset_serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])

# Create upload directories if they don't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['PROFILE_PICTURE_FOLDER'], exist_ok=True)

# Add float to Jinja2 template globals
app.jinja_env.globals['float'] = float


# Customer Model
class Customer(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(11))
    address = db.Column(db.Text)
    city = db.Column(db.String(100))
    state = db.Column(db.String(100))
    zip_code = db.Column(db.String(20))
    country = db.Column(db.String(100))
    gender = db.Column(db.String(10))  # Male, Female, Other
    date_of_birth = db.Column(db.Date)  # Date of birth
    profile_picture_url = db.Column(db.String(255))  # Profile picture path
    email_notifications = db.Column(db.Boolean, default=True)  # Email notifications preference
    order_updates = db.Column(db.Boolean, default=True)  # Order updates preference
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    def set_password(self, password):
        """Hash and set the password"""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Check if the provided password matches the hash"""
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<Customer {self.username}>'

class Address(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    full_address = db.Column(db.Text, nullable=False)
    city = db.Column(db.String(100), nullable=False)
    state = db.Column(db.String(100))
    zip_code = db.Column(db.String(20))
    country = db.Column(db.String(100), default='Philippines')
    is_default = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    customer = db.relationship('Customer', backref='addresses')

# Product Model
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    stock = db.Column(db.Integer, default=0)
    image_url = db.Column(db.String(500))
    brand = db.Column(db.String(100))
    sku = db.Column(db.String(100), unique=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Product {self.name}>'


# Cart Model
class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    customer = db.relationship('Customer', backref='cart_items')
    product = db.relationship('Product', backref='cart_items')
    
    def __repr__(self):
        return f'<Cart {self.customer_id} - {self.product_id}>'


# Order Model
class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_number = db.Column(db.String(50), unique=True, nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    total_amount = db.Column(db.Numeric(10, 2), nullable=False)
    status = db.Column(db.String(20), default='Pending', nullable=False)  # Pending, Shipped, Delivered, Cancelled
    payment_method = db.Column(db.String(50), nullable=False)  # cash_on_delivery, online_payment
    payment_status = db.Column(db.String(20), default='Pending')  # Pending, Paid, Failed
    shipping_address = db.Column(db.Text, nullable=False)
    shipping_city = db.Column(db.String(100), nullable=False)
    shipping_state = db.Column(db.String(100))
    shipping_zip = db.Column(db.String(20))
    shipping_country = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    customer = db.relationship('Customer', backref='orders')
    items = db.relationship('OrderItem', backref='order', cascade='all, delete-orphan')
    payment = db.relationship('Payment', backref='order', uselist=False)
    
    def __repr__(self):
        return f'<Order {self.order_number}>'


# Order Item Model
class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Numeric(10, 2), nullable=False)  # Price at time of order
    subtotal = db.Column(db.Numeric(10, 2), nullable=False)
    
    product = db.relationship('Product', backref='order_items')
    
    def __repr__(self):
        return f'<OrderItem {self.id}>'


# Payment Model
class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False, unique=True)
    payment_method = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    proof_image = db.Column(db.String(500))  # Path to uploaded screenshot
    status = db.Column(db.String(20), default='Pending')  # Pending, Verified, Rejected
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Payment {self.id}>'


# Notification Model
class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=True)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(50), nullable=False)  # order_created, order_shipped, order_delivered, order_cancelled, payment_verified
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    customer = db.relationship('Customer', backref='notifications')
    order = db.relationship('Order', backref='notifications')
    
    def __repr__(self):
        return f'<Notification {self.id}>'


# Password Reset Token Model
class PasswordResetToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    token = db.Column(db.String(255), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False)
    
    customer = db.relationship('Customer', backref='password_reset_tokens')
    
    def is_valid(self):
        return not self.used and datetime.utcnow() < self.expires_at
    
    def __repr__(self):
        return f'<PasswordResetToken {self.id}>'


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(Customer, int(user_id))


@app.context_processor
def inject_cart_count():
    """Make cart count available to all templates"""
    if current_user.is_authenticated:
        cart_count = Cart.query.filter_by(customer_id=current_user.id).count()
        return {'cart_count': cart_count}
    return {'cart_count': 0}


@app.route('/')
def index():
    """Home page"""
    # Get best seller products (latest 4 active products)
    best_products = Product.query.filter_by(is_active=True).order_by(Product.created_at.desc()).limit(4).all()
    return render_template('index.html', best_products=best_products)


@app.route('/about-us')
def about_us():
    """About Us page"""
    return render_template('about_us.html')


@app.route('/blog')
def blog():
    """Blog page"""
    return render_template('blog.html')


@app.route('/contact-us', methods=['GET', 'POST'])
def contact_us():
    """Contact Us page"""
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        
        if not all([name, email, subject, message]):
            flash('Please fill in all fields.', 'error')
            return render_template('contact_us.html')
        
        # Here you can add email sending functionality or save to database
        # For now, just show a success message
        flash('Thank you for contacting us! We will get back to you soon.', 'success')
        return redirect(url_for('contact_us'))
    
    return render_template('contact_us.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    """Customer registration"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        phone = request.form.get('phone', '')
        address = request.form.get('address', '')
        city = request.form.get('city', '')
        state = request.form.get('state', '')
        zip_code = request.form.get('zip_code', '')
        country = request.form.get('country', '')

        # Validation
        errors = []
        
        if not username or not email or not password:
            errors.append('Username, email, and password are required.')
        
        if password != confirm_password:
            errors.append('Passwords do not match.')
        
        if len(password) < 6:
            errors.append('Password must be at least 6 characters long.')
        
        if Customer.query.filter_by(username=username).first():
            errors.append('Username already exists. Please choose a different one.')
        
        if Customer.query.filter_by(email=email).first():
            errors.append('Email already registered. Please use a different email.')
        
        # Validate Philippines phone number format (11 digits starting with 09)
        if phone:
            # Remove any spaces, dashes, or other characters
            phone_clean = ''.join(filter(str.isdigit, phone))
            if not phone_clean.startswith('09'):
                errors.append('Phone number must start with 09 (Philippines format).')
            elif len(phone_clean) != 11:
                errors.append('Phone number must be exactly 11 digits starting with 09 (e.g., 09123456789).')
            else:
                # Store cleaned phone number
                phone = phone_clean

        if errors:
            for error in errors:
                flash(error, 'error')
            return render_template('register.html')

        # Create new customer
        try:
            customer = Customer(
                username=username,
                email=email,
                first_name=first_name,
                last_name=last_name,
                phone=phone,
                address=address,
                city=city,
                state=state,
                zip_code=zip_code,
                country=country
            )
            customer.set_password(password)
            db.session.add(customer)
            db.session.flush()  # Flush to get customer.id
            
            # Create Address entry from registration data if address fields are provided
            if address and (city or state):  # At least address and city/state
                # Use state as city if city is empty (based on form structure)
                address_city = city if city else state
                address_entry = Address(
                    customer_id=customer.id,
                    full_address=address,
                    city=address_city,
                    state=state if city else '',  # Only set state if city was provided
                    zip_code=zip_code or '',
                    country=country or 'Philippines',
                    is_default=True  # First address is default
                )
                db.session.add(address_entry)
            
            db.session.commit()
            flash('Sign up successful! Please sign in.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred during registration. Please try again.', 'error')
            return render_template('register.html')

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Customer login"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = bool(request.form.get('remember'))

        if not username or not password:
            flash('Please enter both username and password.', 'error')
            return render_template('login.html')

        customer = Customer.query.filter_by(username=username).first()

        if customer and customer.check_password(password):
            if not customer.is_active:
                flash('Your account has been deactivated. Please contact support.', 'error')
                return render_template('login.html')
            
            login_user(customer, remember=remember)
            next_page = request.args.get('next')
            flash(f'Welcome back, {customer.first_name}!', 'success')
            return redirect(next_page) if next_page else redirect(url_for('index'))
        else:
            flash('Invalid username or password.', 'error')

    return render_template('login.html')


@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    """Forgot password - request password reset"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        
        if not email:
            flash('Please enter your email address.', 'error')
            return render_template('forgot_password.html')
        
        customer = Customer.query.filter_by(email=email).first()
        
        if customer:
            # Generate reset token
            token = password_reset_serializer.dumps(email, salt='password-reset-salt')
            expires_at = datetime.utcnow() + timedelta(hours=1)
            
            # Store token in database
            reset_token = PasswordResetToken(
                customer_id=customer.id,
                token=token,
                expires_at=expires_at
            )
            db.session.add(reset_token)
            db.session.commit()
            
            # Send email
            reset_url = url_for('reset_password', token=token, _external=True)
            try:
                msg = Message(
                    subject='Password Reset Request - ETR E-Commerce',
                    recipients=[customer.email],
                    html=render_template('emails/password_reset.html', 
                                       customer=customer, 
                                       reset_url=reset_url)
                )
                if not app.config['MAIL_SUPPRESS_SEND']:
                    mail.send(msg)
                flash('Password reset link has been sent to your email address.', 'success')
            except Exception as e:
                # If email fails, still show success message (security best practice)
                # In production, log the error
                flash('Password reset link has been sent to your email address.', 'success')
        else:
            # Don't reveal if email exists (security best practice)
            flash('If an account exists with that email, a password reset link has been sent.', 'success')
        
        return redirect(url_for('login'))
    
    return render_template('forgot_password.html')


@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    """Reset password with token"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    # Verify token
    try:
        email = password_reset_serializer.loads(token, salt='password-reset-salt', max_age=3600)
    except (SignatureExpired, BadSignature):
        flash('Invalid or expired password reset link. Please request a new one.', 'error')
        return redirect(url_for('forgot_password'))
    
    # Check if token exists in database and is valid
    reset_token = PasswordResetToken.query.filter_by(token=token).first()
    if not reset_token or not reset_token.is_valid():
        flash('Invalid or expired password reset link. Please request a new one.', 'error')
        return redirect(url_for('forgot_password'))
    
    customer = Customer.query.filter_by(email=email).first()
    if not customer:
        flash('Invalid password reset link.', 'error')
        return redirect(url_for('forgot_password'))
    
    if request.method == 'POST':
        new_password = request.form.get('new_password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()
        
        if not new_password or not confirm_password:
            flash('Please fill in all fields.', 'error')
            return render_template('reset_password.html', token=token)
        
        if new_password != confirm_password:
            flash('Passwords do not match.', 'error')
            return render_template('reset_password.html', token=token)
        
        if len(new_password) < 6:
            flash('Password must be at least 6 characters long.', 'error')
            return render_template('reset_password.html', token=token)
        
        # Update password
        try:
            customer.set_password(new_password)
            reset_token.used = True
            db.session.commit()
            flash('Your password has been reset successfully. Please login with your new password.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while resetting your password. Please try again.', 'error')
            return render_template('reset_password.html', token=token)
    
    return render_template('reset_password.html', token=token)


@app.route('/logout')
@login_required
def logout():
    """Customer logout"""
    logout_user()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('index'))


@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """Customer profile page"""
    if request.method == 'POST':
        # Update profile information
        customer = current_user
        
        # Update name
        if 'first_name' in request.form:
            customer.first_name = request.form.get('first_name', '').strip()
        if 'last_name' in request.form:
            customer.last_name = request.form.get('last_name', '').strip()
        
        # Update gender
        if 'gender' in request.form:
            customer.gender = request.form.get('gender') or None
        
        # Update date of birth (only if not already set)
        if not customer.date_of_birth:
            if 'birth_day' in request.form and 'birth_month' in request.form and 'birth_year' in request.form:
                day = request.form.get('birth_day')
                month = request.form.get('birth_month')
                year = request.form.get('birth_year')
                if day and month and year:
                    try:
                        customer.date_of_birth = datetime(int(year), int(month), int(day)).date()
                    except ValueError:
                        flash('Invalid date of birth', 'error')
        
        # Handle profile picture upload
        if 'profile_picture' in request.files:
            file = request.files['profile_picture']
            if file and file.filename:
                if allowed_file(file.filename):
                    # Ensure directory exists
                    os.makedirs(app.config['PROFILE_PICTURE_FOLDER'], exist_ok=True)
                    # Save file temporarily to check size
                    filename = secure_filename(f"{customer.id}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{file.filename}")
                    filepath = os.path.join(app.config['PROFILE_PICTURE_FOLDER'], filename)
                    file.save(filepath)
                    
                    # Check file size (1 MB = 1024 * 1024 bytes)
                    file_size = os.path.getsize(filepath)
                    if file_size > 1024 * 1024:
                        os.remove(filepath)
                        flash('File size exceeds 1 MB. Please upload a smaller image.', 'error')
                    else:
                        customer.profile_picture_url = f"uploads/profiles/{filename}"
                else:
                    flash('Invalid file type. Please upload JPEG or PNG image.', 'error')
        
        try:
            db.session.commit()
            flash('Profile updated successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash('Error updating profile. Please try again.', 'error')
        
        return redirect(url_for('profile'))
    
    return render_template('profile.html', customer=current_user)

@app.route('/addresses', methods=['GET', 'POST'])
@login_required
def addresses():
    if request.method == 'POST':
        address = Address(
            customer_id=current_user.id,
            full_address=request.form['full_address'],
            city=request.form['city'],
            state=request.form.get('state', ''),
            zip_code=request.form.get('zip_code', ''),
            country=request.form.get('country', 'Philippines')
        )

        # First address becomes default
        if not Address.query.filter_by(customer_id=current_user.id).count():
            address.is_default = True

        db.session.add(address)
        db.session.commit()
        flash('Address added successfully!', 'success')
        return redirect(url_for('addresses'))

    # Check if customer has address data in Customer model but no Address entries
    # If so, create an Address entry from the Customer's address data
    existing_addresses = Address.query.filter_by(customer_id=current_user.id).all()
    
    if not existing_addresses and current_user.address and (current_user.city or current_user.state):
        # Migrate address from Customer model to Address table
        address_city = current_user.city if current_user.city else current_user.state
        address_entry = Address(
            customer_id=current_user.id,
            full_address=current_user.address,
            city=address_city,
            state=current_user.state if current_user.city else '',
            zip_code=current_user.zip_code or '',
            country=current_user.country or 'Philippines',
            is_default=True
        )
        db.session.add(address_entry)
        db.session.commit()
        # Refresh the query
        existing_addresses = Address.query.filter_by(customer_id=current_user.id).all()
    
    return render_template('addresses.html', addresses=existing_addresses)

@app.route('/addresses/set-default/<int:address_id>', methods=['POST'])
@login_required
def set_default_address(address_id):
    Address.query.filter_by(customer_id=current_user.id).update({'is_default': False})
    address = Address.query.get_or_404(address_id)
    address.is_default = True
    db.session.commit()
    flash('Default address updated!', 'success')
    return redirect(url_for('addresses'))
@app.route('/addresses/edit/<int:address_id>', methods=['POST'])
@login_required
def edit_address(address_id):
    address = Address.query.get_or_404(address_id)

    if address.customer_id != current_user.id:
        abort(403)

    address.full_address = request.form['full_address']
    address.city = request.form['city']
    address.state = request.form.get('state', '')
    address.zip_code = request.form.get('zip_code', '')
    address.country = request.form.get('country', 'Philippines')

    db.session.commit()
    flash('Address updated!', 'success')
    return redirect(url_for('addresses'))
@app.route('/addresses/delete/<int:address_id>', methods=['POST'])
@login_required
def delete_address(address_id):
    address = Address.query.get_or_404(address_id)

    if address.customer_id != current_user.id:
        abort(403)

    db.session.delete(address)
    db.session.commit()
    flash('Address deleted!', 'info')
    return redirect(url_for('addresses'))

@app.route('/products')
def products():
    """Product catalog with search and filter"""
    # Get query parameters
    search = request.args.get('search', '').strip()
    category = request.args.get('category', '').strip()
    min_price = request.args.get('min_price', '')
    max_price = request.args.get('max_price', '')
    sort_by = request.args.get('sort', 'name')  # name, price_low, price_high
    
    # Start with active products
    query = Product.query.filter_by(is_active=True)
    
    # Apply search filter
    if search:
        query = query.filter(
            db.or_(
                Product.name.ilike(f'%{search}%'),
                Product.description.ilike(f'%{search}%'),
                Product.brand.ilike(f'%{search}%')
            )
        )
    
    # Apply category filter
    if category:
        query = query.filter_by(category=category)
    
    # Apply price filters
    if min_price:
        try:
            min_price_float = float(min_price)
            query = query.filter(Product.price >= min_price_float)
        except ValueError:
            pass
    
    if max_price:
        try:
            max_price_float = float(max_price)
            query = query.filter(Product.price <= max_price_float)
        except ValueError:
            pass
    
    # Apply sorting
    if sort_by == 'price_low':
        query = query.order_by(Product.price.asc())
    elif sort_by == 'price_high':
        query = query.order_by(Product.price.desc())
    else:
        query = query.order_by(Product.name.asc())
    
    # Get all products for pagination
    products = query.all()
    
    # Get unique categories for filter dropdown
    categories = db.session.query(Product.category).distinct().all()
    categories = [cat[0] for cat in categories if cat[0]]
    
    return render_template(
        'products.html',
        products=products,
        categories=categories,
        search=search,
        selected_category=category,
        min_price=min_price,
        max_price=max_price,
        sort_by=sort_by
    )


@app.route('/product/<int:product_id>')
def product_detail(product_id):
    """Product detail page"""
    product = Product.query.get_or_404(product_id)
    
    if not product.is_active:
        flash('This product is no longer available.', 'error')
        return redirect(url_for('products'))
    
    # Get related products (same category, excluding current product)
    related_products = Product.query.filter(
        Product.category == product.category,
        Product.id != product.id,
        Product.is_active == True
    ).limit(4).all()
    
    return render_template('product_detail.html', product=product, related_products=related_products)


@app.route('/seed-products')
def seed_products():
    """Seed database with sample products (for development/testing)"""
    try:
        # Clear existing products if any
        deleted_count = Product.query.delete()
        db.session.commit()
        if deleted_count > 0:
            flash(f'Cleared {deleted_count} existing products.', 'info')
    except Exception as e:
        db.session.rollback()
        flash(f'Error clearing products: {str(e)}', 'error')
    
    sample_products = [
        # Electronics - 6 products
        {
            'name': 'Wireless Bluetooth Headphones',
            'description': 'High-quality wireless headphones with noise cancellation and 30-hour battery life. Perfect for music lovers and professionals.',
            'price': 2999.99,
            'category': 'Electronics',
            'stock': 50,
            'brand': 'AudioTech',
            'sku': 'ATH-WB-001',
            'image_url': 'images/products/headset.jpg'
        },
        {
            'name': 'Smartphone 128GB',
            'description': 'Latest smartphone with 128GB storage, triple camera system, and fast charging. Available in multiple colors.',
            'price': 24999.99,
            'category': 'Electronics',
            'stock': 25,
            'brand': 'Samsung',
            'sku': 'TP-SM-128',
            'image_url': 'images/products/smartP.jpg'
        },
        {
            'name': 'Wireless Mouse',
            'description': 'Ergonomic wireless mouse with long battery life and precise tracking. Compatible with all operating systems.',
            'price': 599.99,
            'category': 'Electronics',
            'stock': 80,
            'brand': 'LogiTech',
            'sku': 'TM-WM-001',
            'image_url': 'images/products/wmouse.jpg'
        },
        {
            'name': 'Gaming Keyboard',
            'description': 'Mechanical gaming keyboard with RGB backlighting and programmable keys. Perfect for gamers.',
            'price': 4499.99,
            'category': 'Electronics',
            'stock': 35,
            'brand': 'LogiTech',
            'sku': 'GT-GK-001',
            'image_url': 'images/products/keyb.jpg'
        },
        {
            'name': 'Smart Watch Pro',
            'description': 'Feature-rich smartwatch with fitness tracking, heart rate monitor, GPS, and 7-day battery life. Water-resistant design.',
            'price': 8999.99,
            'category': 'Electronics',
            'stock': 30,
            'brand': 'AppleStore',
            'sku': 'TW-SW-001',
            'image_url': 'images/products/smartW.jpg'
        },
        {
            'name': '4K Ultra HD TV 55"',
            'description': '55-inch 4K Ultra HD Smart TV with HDR support, built-in streaming apps, and voice control. Perfect for home entertainment.',
            'price': 34999.99,
            'category': 'Electronics',
            'stock': 15,
            'brand': 'Life Good',
            'sku': 'VT-TV-55',
            'image_url': 'images/products/tv.jpg'
        },
        
        # Clothing - 6 products
        {
            'name': 'Cotton T-Shirt',
            'description': 'Comfortable 100% cotton t-shirt. Available in various sizes and colors. Perfect for everyday wear.',
            'price': 499.99,
            'category': 'Clothing',
            'stock': 100,
            'brand': 'MNL-Clothing',
            'sku': 'FW-TS-001',
            'image_url': 'images/products/tshirt.jpg'
        },
        {
            'name': 'Denim Jeans',
            'description': 'Classic fit denim jeans made from premium cotton. Available in various sizes and washes.',
            'price': 1299.99,
            'category': 'Clothing',
            'stock': 55,
            'brand': 'MNL-Clothing',
            'sku': 'FW-DJ-001',
            'image_url': 'images/products/jeans.jpg'
        },
        {
            'name': 'Hooded Sweatshirt',
            'description': 'Warm and comfortable hooded sweatshirt with front pocket. Perfect for casual wear and outdoor activities.',
            'price': 1499.99,
            'category': 'Clothing',
            'stock': 65,
            'brand': 'ComfortWear',
            'sku': 'CW-HS-001',
            'image_url': 'images/products/hood.jpg'
        },
        {
            'name': 'Polo Shirt',
            'description': 'Classic polo shirt made from breathable cotton blend. Perfect for business casual or weekend wear.',
            'price': 799.99,
            'category': 'Clothing',
            'stock': 70,
            'brand': 'HUILISHI',
            'sku': 'SW-PS-001',
            'image_url': 'images/products/poloS.jpg'
        },
        {
            'name': 'Summer Dress',
            'description': 'Lightweight and elegant summer dress with floral pattern. Perfect for warm weather and special occasions.',
            'price': 1899.99,
            'category': 'Clothing',
            'stock': 40,
            'brand': 'Elegance',
            'sku': 'EL-SD-001',
            'image_url': 'images/products/summerD.jpg'
        },
        {
            'name': 'Leather Jacket',
            'description': 'Genuine leather jacket with classic design. Durable and stylish, perfect for all seasons.',
            'price': 5999.99,
            'category': 'Clothing',
            'stock': 20,
            'brand': 'MNL-Clothing',
            'sku': 'LC-LJ-001',
            'image_url': 'images/products/letherJack.jpg'
        },
        
        # Footwear - 6 products
        {
            'name': 'Running Shoes',
            'description': 'Lightweight running shoes with cushioned sole and breathable mesh upper. Ideal for jogging and sports.',
            'price': 3499.99,
            'category': 'Footwear',
            'stock': 40,
            'brand': 'SportCenter',
            'sku': 'SM-RS-001',
            'image_url': 'images/products/nikeS.jpg'
        },
        {
            'name': 'Casual Sneakers',
            'description': 'Comfortable casual sneakers with modern design. Perfect for everyday wear and walking.',
            'price': 2499.99,
            'category': 'Footwear',
            'stock': 50,
            'brand': 'SportCenter',
            'sku': 'CS-CS-001',
            'image_url': 'images/products/Sneak.jpg'
        },
        {
            'name': 'Leather Shoes',
            'description': 'Elegant leather dress shoes with classic design. Perfect for formal occasions and business wear.',
            'price': 2799.99,
            'category': 'Footwear',
            'stock': 30,
            'brand': 'Bragais',
            'sku': 'FS-LDS-001',
            'image_url': 'images/products/lshoes.jpg'
        },
        {
            'name': 'Hiking Boots',
            'description': 'Durable hiking boots with waterproof membrane and superior grip. Perfect for outdoor adventures.',
            'price': 1999,
            'category': 'Footwear',
            'stock': 25,
            'brand': 'AdventureFoot',
            'sku': 'AF-HB-001',
            'image_url': 'images/products/hikingSh.jpg'
        },
        {
            'name': 'Sandals',
            'description': 'Comfortable sandals with adjustable straps and cushioned footbed. Perfect for summer and beach.',
            'price': 899,
            'category': 'Footwear',
            'stock': 60,
            'brand': 'SummerStep',
            'sku': 'SS-SD-001',
            'image_url': 'images/products/sandal.jpg'
        },
        {
            'name': 'Basketball Shoes',
            'description': 'High-performance basketball shoes with excellent ankle support and superior traction. Designed for athletes.',
            'price': 5499.99,
            'category': 'Footwear',
            'stock': 35,
            'brand': 'SportCenter',
            'sku': 'SM-BS-001',
            'image_url': 'images/products/lebronS.jpg'
        },
        
        # Accessories - 6 products
        {
            'name': 'Laptop Backpack',
            'description': 'Durable laptop backpack with padded compartment for laptops up to 15.6 inches. Multiple pockets for organization.',
            'price': 1299.99,
            'category': 'Accessories',
            'stock': 60,
            'brand': 'TravelGear',
            'sku': 'TG-LB-001',
            'image_url': 'images/products/laptopB.jpg'
        },
        {
            'name': 'Leather Wallet',
            'description': 'Genuine leather wallet with multiple card slots and cash compartment. Classic design.',
            'price': 799,
            'category': 'Accessories',
            'stock': 45,
            'brand': 'LeatherCraft',
            'sku': 'LC-WL-001',
            'image_url': 'images/products/walletL.jpg'
        },
        {
            'name': 'Stainless Steel Water Bottle',
            'description': 'Insulated stainless steel water bottle keeps drinks cold for 24 hours or hot for 12 hours. BPA-free.',
            'price': 699,
            'category': 'Accessories',
            'stock': 90,
            'brand': 'EcoBottle',
            'sku': 'EB-WB-001',
            'image_url': 'images/products/tumbler.jpg'
        },
        {
            'name': 'Sunglasses',
            'description': 'Stylish sunglasses with UV400 protection and polarized lenses. Available in multiple frame colors.',
            'price': 1299.99,
            'category': 'Accessories',
            'stock': 55,
            'brand': 'Dior',
            'sku': 'SS-SG-001',
            'image_url': 'images/products/Iglases.jpg'
        },
        {
            'name': 'Leather Belt',
            'description': 'Genuine leather belt with classic buckle design. Adjustable size to fit various waist sizes.',
            'price': 299,
            'category': 'Accessories',
            'stock': 50,
            'brand': 'LeatherCraft',
            'sku': 'LC-LB-001',
            'image_url': 'images/products/belts.jpg'
        },
        {
            'name': 'Smartphone Case',
            'description': 'Protective smartphone case with shock-absorbing design. Available for various phone models.',
            'price': 399,
            'category': 'Accessories',
            'stock': 120,
            'brand': 'ProtectTech',
            'sku': 'PT-SC-001',
            'image_url': 'images/products/case.jpg'
        },
        
        # Home & Kitchen - 6 products
        {
            'name': 'Coffee Maker',
            'description': 'Programmable coffee maker with 12-cup capacity. Auto shut-off and brew strength control.',
            'price': 14999.99,
            'category': 'Home & Kitchen',
            'stock': 30,
            'brand': 'BrewMaster',
            'sku': 'BM-CM-001',
            'image_url': 'images/products/CM.jpg'
        },
        {
            'name': 'Air Fryer',
            'description': 'Digital air fryer with large capacity. Cook healthier meals with less oil. Easy to clean and use.',
            'price': 4999.99,
            'category': 'Home & Kitchen',
            'stock': 25,
            'brand': 'KitchenPro',
            'sku': 'KP-AF-001',
            'image_url': 'images/products/airf.jpg'
        },
        {
            'name': 'Blender',
            'description': 'High-speed blender with multiple settings. Perfect for smoothies, soups, and sauces. Easy to clean.',
            'price': 1499.99,
            'category': 'Home & Kitchen',
            'stock': 35,
            'brand': 'BlendTech',
            'sku': 'BT-BL-001',
            'image_url': 'images/products/blender.jpg'
        },
        {
            'name': 'Dinnerware Set',
            'description': 'Complete dinnerware set for 6 people. Includes plates, bowls, and mugs. Dishwasher safe and durable.',
            'price': 1499.99,
            'category': 'Home & Kitchen',
            'stock': 40,
            'brand': 'HomeStyle',
            'sku': 'HS-DS-001',
            'image_url': 'images/products/dinnerSet.jpg'
        },
        {
            'name': 'Cookware Set',
            'description': 'Non-stick cookware set with 10 pieces. Includes various pots and pans. Oven safe up to 400°F.',
            'price': 5999.99,
            'category': 'Home & Kitchen',
            'stock': 20,
            'brand': 'ChefPro',
            'sku': 'CP-CS-001',
            'image_url': 'images/products/cookset.jpg'
        },
        {
            'name': 'Stand Mixer',
            'description': 'Powerful stand mixer with multiple attachments. Perfect for baking and mixing. Includes dough hook and whisk.',
            'price': 6999.99,
            'category': 'Home & Kitchen',
            'stock': 15,
            'brand': 'BakeMaster',
            'sku': 'BM-SM-001',
            'image_url': 'images/products/KT.jpg'
        },
        
        # Sports & Fitness - 6 products
        {
            'name': 'Yoga Mat',
            'description': 'Non-slip yoga mat with extra cushioning. Perfect for yoga, pilates, and exercise routines.',
            'price': 199.99,
            'category': 'Sports & Fitness',
            'stock': 75,
            'brand': 'FitLife',
            'sku': 'FL-YM-001',
            'image_url': 'images/products/yogaM.jpg'
        },
        {
            'name': 'Dumbbell Set',
            'description': 'Adjustable dumbbell set with weights from 5kg to 25kg. Perfect for home workouts and strength training.',
            'price': 1099.99,
            'category': 'Sports & Fitness',
            'stock': 20,
            'brand': 'PowerFit',
            'sku': 'PF-DS-001',
            'image_url': 'images/products/dumpbell.jpg'
        },
        {
            'name': 'Resistance Bands Set',
            'description': 'Complete resistance bands set with 5 different resistance levels. Includes door anchor and exercise guide.',
            'price': 299.99,
            'category': 'Sports & Fitness',
            'stock': 50,
            'brand': 'FlexBand',
            'sku': 'FB-RS-001',
            'image_url': 'images/products/resistance.jpg'
        },
        {
            'name': 'Jump Rope',
            'description': 'Professional speed jump rope with adjustable length. Perfect for cardio workouts and weight loss.',
            'price': 199.99,
            'category': 'Sports & Fitness',
            'stock': 80,
            'brand': 'SpeedJump',
            'sku': 'SJ-JR-001',
            'image_url': 'images/products/jumprope.jpg'
        },
        {
            'name': 'Foam Roller',
            'description': 'High-density foam roller for muscle recovery and massage. Helps reduce muscle soreness and improve flexibility.',
            'price': 299.99,
            'category': 'Sports & Fitness',
            'stock': 45,
            'brand': 'RecoveryPro',
            'sku': 'RP-FR-001',
            'image_url': 'images/products/roler.jpg'
        },
        {
            'name': 'Exercise Bike',
            'description': 'Indoor exercise bike with adjustable resistance and digital display. Perfect for home cardio workouts.',
            'price': 12999.99,
            'category': 'Sports & Fitness',
            'stock': 10,
            'brand': 'CardioFit',
            'sku': 'CF-EB-001',
            'image_url': 'images/products/bike.jpg'
        }
    ]
    
    try:
        for product_data in sample_products:
            product = Product(**product_data)
            db.session.add(product)
        db.session.commit()
        flash(f'Successfully added {len(sample_products)} sample products!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding products: {str(e)}', 'error')
    
    return redirect(url_for('products'))


@app.route('/clear-products')
def clear_products():
    """Clear all products from database (for testing)"""
    try:
        deleted_count = Product.query.delete()
        db.session.commit()
        flash(f'Successfully deleted {deleted_count} products from database.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error clearing products: {str(e)}', 'error')
    return redirect(url_for('products'))


# Cart Routes
@app.route('/cart')
@login_required
def cart():
    """View shopping cart"""
    cart_items = Cart.query.filter_by(customer_id=current_user.id).all()
    total = sum(float(item.product.price) * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)


@app.route('/cart/add/<int:product_id>', methods=['POST'])
@login_required
def add_to_cart(product_id):
    """Add product to cart"""
    product = Product.query.get_or_404(product_id)
    
    if not product.is_active or product.stock <= 0:
        flash('Product is not available.', 'error')
        return redirect(url_for('product_detail', product_id=product_id))
    
    quantity = int(request.form.get('quantity', 1))
    
    if quantity > product.stock:
        flash(f'Only {product.stock} items available in stock.', 'error')
        return redirect(url_for('product_detail', product_id=product_id))
    
    # Check if item already in cart
    cart_item = Cart.query.filter_by(
        customer_id=current_user.id,
        product_id=product_id
    ).first()
    
    if cart_item:
        new_quantity = cart_item.quantity + quantity
        if new_quantity > product.stock:
            flash(f'Only {product.stock} items available in stock.', 'error')
            return redirect(url_for('product_detail', product_id=product_id))
        cart_item.quantity = new_quantity
    else:
        cart_item = Cart(
            customer_id=current_user.id,
            product_id=product_id,
            quantity=quantity
        )
        db.session.add(cart_item)
    
    db.session.commit()
    flash(f'{product.name} added to cart!', 'success')
    return redirect(url_for('cart'))


@app.route('/buy-now/<int:product_id>', methods=['POST'])
@login_required
def buy_now(product_id):
    """Buy Now - Add product to cart and proceed to checkout"""
    product = Product.query.get_or_404(product_id)
    
    if not product.is_active or product.stock <= 0:
        flash('Product is not available.', 'error')
        return redirect(url_for('product_detail', product_id=product_id))
    
    quantity = int(request.form.get('quantity', 1))
    
    if quantity > product.stock:
        flash(f'Only {product.stock} items available in stock.', 'error')
        return redirect(url_for('product_detail', product_id=product_id))
    
    # Check if item already in cart
    cart_item = Cart.query.filter_by(
        customer_id=current_user.id,
        product_id=product_id
    ).first()
    
    if cart_item:
        # Update quantity for buy now
        if quantity > product.stock:
            flash(f'Only {product.stock} items available in stock.', 'error')
            return redirect(url_for('product_detail', product_id=product_id))
        cart_item.quantity = quantity
    else:
        # Add new item to cart
        cart_item = Cart(
            customer_id=current_user.id,
            product_id=product_id,
            quantity=quantity
        )
        db.session.add(cart_item)
    
    db.session.commit()
    
    # Store the product_id in session so checkout only processes this item
    session['buy_now_product_id'] = product_id
    
    return redirect(url_for('checkout'))


@app.route('/cart/update/<int:cart_id>', methods=['POST'])
@login_required
def update_cart(cart_id):
    """Update cart item quantity"""
    cart_item = Cart.query.get_or_404(cart_id)
    
    if cart_item.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('cart'))
    
    quantity = int(request.form.get('quantity', 1))
    
    if quantity <= 0:
        db.session.delete(cart_item)
        db.session.commit()
        flash('Item removed from cart.', 'info')
        return redirect(url_for('cart'))
    
    if quantity > cart_item.product.stock:
        flash(f'Only {cart_item.product.stock} items available in stock.', 'error')
        return redirect(url_for('cart'))
    
    cart_item.quantity = quantity
    db.session.commit()
    flash('Cart updated!', 'success')
    return redirect(url_for('cart'))


@app.route('/cart/remove/<int:cart_id>', methods=['POST'])
@login_required
def remove_from_cart(cart_id):
    """Remove item from cart"""
    cart_item = Cart.query.get_or_404(cart_id)
    
    if cart_item.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('cart'))
    
    db.session.delete(cart_item)
    db.session.commit()
    flash('Item removed from cart.', 'success')
    return redirect(url_for('cart'))


# Checkout Routes
@app.route('/checkout', methods=['GET', 'POST'])
@login_required

def checkout():
    """Checkout page"""
    # Check if this is a "Buy Now" flow - only process specific product
    buy_now_product_id = session.get('buy_now_product_id')
    
    if buy_now_product_id:
        # Only get the specific product for buy now
        cart_items = Cart.query.filter_by(
            customer_id=current_user.id,
            product_id=buy_now_product_id
        ).all()
    else:
        # Regular checkout - get all cart items
        cart_items = Cart.query.filter_by(customer_id=current_user.id).all()
    
    if not cart_items:
        # Clear buy_now flag if cart is empty
        session.pop('buy_now_product_id', None)
        flash('Your cart is empty.', 'error')
        return redirect(url_for('cart'))
    
    # Check stock availability
    for item in cart_items:
        if item.quantity > item.product.stock:
            flash(f'{item.product.name} has insufficient stock.', 'error')
            return redirect(url_for('cart'))
    
    if request.method == 'POST':
        payment_method = request.form.get('payment_method')
        shipping_address = request.form.get('shipping_address')
        shipping_city = request.form.get('shipping_city')
        shipping_state = request.form.get('shipping_state', '')
        shipping_zip = request.form.get('shipping_zip', '')
        shipping_country = request.form.get('shipping_country', 'Philippines')
        
        # Check if payment details were provided
        if payment_method == 'credit_debit_card':
            card_number = request.form.get('card_number', '').strip()
            if not card_number:
                flash('Please fill in all required fields.', 'error')
                subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
                return render_template('checkout.html', cart_items=cart_items, total=subtotal, customer=current_user)
        elif payment_method == 'gcash_payment':
            gcash_phone = request.form.get('gcash_phone', '').strip()
            gcash_name = request.form.get('gcash_name', '').strip()
            if not gcash_phone or not gcash_name:
                flash('Please fill in all required fields.', 'error')
                subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
                return render_template('checkout.html', cart_items=cart_items, total=subtotal, customer=current_user)
        
        if not all([payment_method, shipping_address, shipping_city]):
            flash('Please fill in all required fields.', 'error')
            subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
            return render_template('checkout.html', cart_items=cart_items, total=subtotal, customer=current_user)
        
        # Calculate total
        subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
        shipping_fee = 8.00  # Standard shipping fee
        total = subtotal + shipping_fee
        
        try:
            # Generate order number
            order_number = f'ORD-{datetime.now().strftime("%Y%m%d")}-{current_user.id}-{Order.query.count() + 1}'
            
            # Create order
            # Determine payment status based on payment method
            # GCash and Credit/Debit Card are processed immediately, so they go to "To Ship"
            # Cash on Delivery and Online Payment start as "To Pay"
            if payment_method in ['gcash_payment', 'credit_debit_card']:
                initial_payment_status = 'Paid'  # Goes directly to "To Ship"
            else:
                initial_payment_status = 'Pending'  # Stays in "To Pay"
            
            order = Order(
                order_number=order_number,
                customer_id=current_user.id,
                total_amount=total,
                payment_method=payment_method,
                payment_status=initial_payment_status,
                shipping_address=shipping_address,
                shipping_city=shipping_city,
                shipping_state=shipping_state,
                shipping_zip=shipping_zip,
                shipping_country=shipping_country,
                status='Pending'
            )
            db.session.add(order)
            db.session.flush()
            
            # Create order items and update stock
            for item in cart_items:
                # Refresh product from database to get latest stock
                product = Product.query.get(item.product_id)
                if not product:
                    raise ValueError(f'Product {item.product_id} not found')
                
                # Double-check stock availability
                if item.quantity > product.stock:
                    raise ValueError(f'Insufficient stock for {product.name}. Available: {product.stock}, Requested: {item.quantity}')
                
                order_item = OrderItem(
                    order_id=order.id,
                    product_id=item.product_id,
                    quantity=item.quantity,
                    price=product.price,
                    subtotal=float(product.price) * item.quantity
                )
                db.session.add(order_item)
                
                # Update product stock - decrement by the quantity purchased
                product.stock -= item.quantity
                
                # Ensure stock doesn't go negative (safety check)
                if product.stock < 0:
                    product.stock = 0
            
            # Create payment record
            # Only online_payment requires proof upload
            # gcash_payment and credit_debit_card are processed directly
            is_online_payment = payment_method == 'online_payment'
            payment = Payment(
                order_id=order.id,
                payment_method=payment_method,
                amount=total,
                status='Pending' if is_online_payment else 'Verified'
            )
            db.session.add(payment)
            
            # Create notification for order creation
            if current_user.order_updates:
                notification = Notification(
                    customer_id=current_user.id,
                    order_id=order.id,
                    title='Order Placed',
                    message=f'Your order #{order.order_number} has been placed successfully. Total: ₱{total:.2f}',
                    type='order_created'
                )
                db.session.add(notification)
            
            # Send order confirmation email
            send_order_email(current_user, order, 'order_placed')
            
            # Clear cart items that were included in the order
            for item in cart_items:
                db.session.delete(item)
            
            # Clear buy_now flag from session after successful order
            session.pop('buy_now_product_id', None)
            
            db.session.commit()
            
            # Redirect based on payment method
            if payment_method == 'credit_debit_card':
                # For credit/debit card, redirect to orders page (My Purchase)
                flash('Order placed successfully! Your card payment has been processed.', 'success')
                return redirect(url_for('orders'))
            elif payment_method == 'gcash_payment':
                # For GCash payment, redirect to orders page (My Purchase)
                flash('Order placed successfully! Your GCash payment has been processed.', 'success')
                return redirect(url_for('orders'))
            elif payment_method == 'online_payment':
                # For other online payments, redirect to upload proof
                flash('Order created! Please upload proof of payment.', 'success')
                return redirect(url_for('upload_payment', order_id=order.id))
            else:
                # Cash on delivery
                flash('Order placed successfully!', 'success')
                return redirect(url_for('order_detail', order_id=order.id))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while processing your order. Please try again.', 'error')
            subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
            return render_template('checkout.html', cart_items=cart_items, total=subtotal, customer=current_user)
    
    subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
    return render_template('checkout.html', cart_items=cart_items, total=subtotal, customer=current_user)


@app.route('/order/<int:order_id>/upload-payment', methods=['GET', 'POST'])
@login_required
def upload_payment(order_id):
    """Upload proof of payment"""
    order = Order.query.get_or_404(order_id)
    
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    
    # Check if payment method requires proof upload
    if order.payment_method not in ['online_payment', 'gcash_payment', 'credit_debit_card']:
        flash('This order does not require payment upload.', 'error')
        return redirect(url_for('order_detail', order_id=order.id))
    
    if request.method == 'POST':
        if 'proof_image' not in request.files:
            flash('No file selected.', 'error')
            return render_template('upload_payment.html', order=order)
        
        file = request.files['proof_image']
        
        if file.filename == '':
            flash('No file selected.', 'error')
            return render_template('upload_payment.html', order=order)
        
        if file and allowed_file(file.filename):
            filename = secure_filename(f'{order.order_number}_{datetime.now().strftime("%Y%m%d%H%M%S")}_{file.filename}')
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Update payment
            payment = Payment.query.filter_by(order_id=order.id).first()
            if payment:
                payment.proof_image = f'uploads/payments/{filename}'
                payment.status = 'Pending'
                db.session.commit()
                flash('Proof of payment uploaded successfully! We will verify it soon.', 'success')
                return redirect(url_for('order_detail', order_id=order.id))
    
    return render_template('upload_payment.html', order=order)


def allowed_file(filename):
    """Check if file extension is allowed"""
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# Order Routes
@app.route('/orders')
@login_required
def orders():
    """View all orders with status filtering"""
    status_filter = request.args.get('status', 'all')
    search_query = request.args.get('search', '').strip()
    
    # Base query
    query = Order.query.filter_by(customer_id=current_user.id)
    
    # Apply status filter
    if status_filter == 'to_pay':
        # Orders that need payment (Pending status with Pending payment)
        query = query.filter(
            Order.status == 'Pending',
            Order.payment_status == 'Pending'
        )
    elif status_filter == 'to_ship':
        # Orders paid but not yet shipped
        query = query.filter(
            Order.status == 'Pending',
            db.or_(
                Order.payment_status == 'Paid',
                Order.payment_status == 'Verified'
            )
        )
    elif status_filter == 'to_receive':
        # Orders that are shipped
        query = query.filter(Order.status == 'Shipped')
    elif status_filter == 'completed':
        # Orders that are delivered
        query = query.filter(Order.status == 'Delivered')
    elif status_filter == 'cancelled':
        # Cancelled orders
        query = query.filter(Order.status == 'Cancelled')
    elif status_filter == 'all':
        # 'all' shows only To Pay and To Ship orders (exclude cancelled, shipped, delivered)
        # To Pay: status='Pending' AND payment_status='Pending'
        # To Ship: status='Pending' AND (payment_status='Paid' OR payment_status='Verified')
        query = query.filter(
            Order.status == 'Pending'
        )
    
    # Apply search filter
    if search_query:
        query = query.join(OrderItem).join(Product).filter(
            db.or_(
                Order.order_number.ilike(f'%{search_query}%'),
                Product.name.ilike(f'%{search_query}%')
            )
        ).distinct()
    
    orders_list = query.order_by(Order.created_at.desc()).all()
    
    # Count orders in each category
    # 'all' count = To Pay + To Ship (only Pending orders, exclude cancelled, shipped, delivered)
    all_count = Order.query.filter(
        Order.customer_id == current_user.id,
        Order.status == 'Pending'
    ).count()
    to_pay_count = Order.query.filter_by(customer_id=current_user.id, status='Pending', payment_status='Pending').count()
    to_ship_count = Order.query.filter(
        Order.customer_id == current_user.id,
        Order.status == 'Pending',
        db.or_(Order.payment_status == 'Paid', Order.payment_status == 'Verified')
    ).count()
    to_receive_count = Order.query.filter_by(customer_id=current_user.id, status='Shipped').count()
    completed_count = Order.query.filter_by(customer_id=current_user.id, status='Delivered').count()
    cancelled_count = Order.query.filter_by(customer_id=current_user.id, status='Cancelled').count()
    
    return render_template('orders.html', 
                         orders=orders_list,
                         status_filter=status_filter,
                         search_query=search_query,
                         counts={
                             'all': all_count,
                             'to_pay': to_pay_count,
                             'to_ship': to_ship_count,
                             'to_receive': to_receive_count,
                             'completed': completed_count,
                             'cancelled': cancelled_count
                         })


@app.route('/orders/clear-cancelled', methods=['POST'])
@login_required
def clear_cancelled_orders():
    """Delete all cancelled orders for the current user"""
    cancelled_orders = Order.query.filter_by(
        customer_id=current_user.id,
        status='Cancelled'
    ).all()
    
    for order in cancelled_orders:
        # Delete related payment records first
        if order.payment:
            db.session.delete(order.payment)
        
        # Delete related notifications
        Notification.query.filter_by(order_id=order.id).delete()
        
        # Delete the order (OrderItems will be deleted automatically due to cascade)
        db.session.delete(order)
    
    db.session.commit()
    flash('All cancelled orders have been deleted.', 'success')
    return redirect(url_for('orders', status='cancelled'))


@app.route('/orders/cancel/<int:order_id>', methods=['POST'])
@login_required
def cancel_order(order_id):
    """Cancel an order (only if status is To Pay)"""
    order = Order.query.get_or_404(order_id)
    
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    
    # Only allow cancellation if order is in "To Pay" status
    if order.status != 'Pending' or order.payment_status != 'Pending':
        flash('This order cannot be cancelled.', 'error')
        return redirect(url_for('orders'))
    
    # Restore product stock
    for item in order.items:
        # Refresh product from database to get latest stock
        product = Product.query.get(item.product_id)
        if product:
            # Restore the stock by adding back the quantity that was purchased
            product.stock += item.quantity
    
    # Update order status
    order.status = 'Cancelled'
    order.payment_status = 'Cancelled'
    
    # Create notification for order cancellation
    if current_user.order_updates:
        notification = Notification(
            customer_id=current_user.id,
            order_id=order.id,
            title='Order Cancelled',
            message=f'Your order #{order.order_number} has been cancelled. Refund will be processed if applicable.',
            type='order_cancelled'
        )
        db.session.add(notification)
    
    db.session.commit()
    flash('Order cancelled successfully.', 'success')
    return redirect(url_for('orders', status='cancelled'))


@app.route('/order/<int:order_id>/buy-again', methods=['POST'])
@login_required
def buy_again(order_id):
    """Buy Again - Add all items from a cancelled order back to cart"""
    order = Order.query.get_or_404(order_id)
    
    # Check if order belongs to current user
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    
    # Only allow buy again for cancelled orders
    if order.status != 'Cancelled':
        flash('You can only buy again from cancelled orders.', 'error')
        return redirect(url_for('order_detail', order_id=order.id))
    
    items_added = 0
    items_skipped = []
    
    try:
        # Add each item from the order back to cart
        for order_item in order.items:
            product = Product.query.get(order_item.product_id)
            
            # Check if product still exists and is active
            if not product:
                items_skipped.append('Unknown product (no longer available)')
                continue
            
            if not product.is_active:
                items_skipped.append(f'{product.name} (no longer available)')
                continue
            
            # Check stock availability
            quantity_to_add = min(order_item.quantity, product.stock) if product.stock > 0 else 0
            
            if quantity_to_add == 0:
                items_skipped.append(f'{product.name} (out of stock)')
                continue
            
            # Check if item already in cart
            cart_item = Cart.query.filter_by(
                customer_id=current_user.id,
                product_id=product.id
            ).first()
            
            if cart_item:
                # Update quantity, but don't exceed stock
                new_quantity = cart_item.quantity + quantity_to_add
                if new_quantity > product.stock:
                    new_quantity = product.stock
                cart_item.quantity = new_quantity
            else:
                # Add new item to cart
                cart_item = Cart(
                    customer_id=current_user.id,
                    product_id=product.id,
                    quantity=quantity_to_add
                )
                db.session.add(cart_item)
            
            items_added += 1
        
        db.session.commit()
        
        if items_added > 0:
            flash(f'{items_added} item(s) added to cart successfully!', 'success')
        if items_skipped:
            flash(f'Some items could not be added: {", ".join(items_skipped)}', 'info')
        
        if items_added == 0:
            flash('No items could be added to cart. Products may be out of stock or no longer available.', 'error')
            return redirect(url_for('order_detail', order_id=order.id))
        
        return redirect(url_for('cart'))
        
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while adding items to cart. Please try again.', 'error')
        return redirect(url_for('order_detail', order_id=order.id))


@app.route('/order/<int:order_id>')
@login_required
def order_detail(order_id):
    """View order details with automatic status progression"""
    order = Order.query.get_or_404(order_id)
    
    # Check if order belongs to current user
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    
    # Auto-update order status: If order is in "To Pay" (Pending status with Pending payment)
    # and 1 minute has passed since creation, move to "To Ship" (update payment_status to Paid)
    if order.status == 'Pending' and order.payment_status == 'Pending':
        time_since_creation = datetime.utcnow() - order.created_at
        if time_since_creation.total_seconds() >= 60:  # 1 minute = 60 seconds
            # Move from "To Pay" to "To Ship" by updating payment_status
            order.payment_status = 'Paid'
            order.updated_at = datetime.utcnow()
            db.session.commit()
            
            # Create notification for order moving to "To Ship"
            if current_user.order_updates:
                notification = Notification(
                    customer_id=current_user.id,
                    order_id=order.id,
                    title='Order Processing',
                    message=f'Your order #{order.order_number} is now being prepared for shipment!',
                    type='order_processing'
                )
                db.session.add(notification)
                db.session.commit()
    
    payment = Payment.query.filter_by(order_id=order.id).first()
    return render_template('order_detail.html', order=order, payment=payment)
    """View order details"""
    order = Order.query.get_or_404(order_id)
    
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    
    payment = Payment.query.filter_by(order_id=order.id).first()
    return render_template('order_detail.html', order=order, payment=payment)


@app.route('/notification-settings', methods=['GET', 'POST'])
@login_required
def notification_settings():
    """Notification settings page"""
    if request.method == 'POST':
        # Update notification preferences
        email_notifications = request.form.get('email_notifications') == 'on'
        order_updates = request.form.get('order_updates') == 'on'
        
        current_user.email_notifications = email_notifications
        current_user.order_updates = order_updates
        db.session.commit()
        flash('Notification settings updated successfully!', 'success')
        return redirect(url_for('notification_settings'))
    
    return render_template('notification_settings.html', 
                         customer=current_user)


@app.route('/notifications')
@login_required
def notifications():
    """View all notifications"""
    notifications_list = Notification.query.filter_by(customer_id=current_user.id).order_by(Notification.created_at.desc()).all()
    return render_template('notifications.html', notifications=notifications_list)


@app.route('/notifications/mark-read/<int:notification_id>', methods=['POST'])
@login_required
def mark_notification_read(notification_id):
    """Mark a notification as read"""
    notification = Notification.query.get_or_404(notification_id)
    
    if notification.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('notifications'))
    
    notification.is_read = True
    db.session.commit()
    return redirect(url_for('notifications'))


@app.route('/notifications/clear-all', methods=['POST'])
@login_required
def clear_all_notifications():
    """Clear all notifications for the current user"""
    Notification.query.filter_by(customer_id=current_user.id).delete()
    db.session.commit()
    flash('All notifications cleared.', 'success')
    return redirect(url_for('notifications'))


@app.route('/notifications/delete/<int:notification_id>', methods=['POST'])
@login_required
def delete_notification(notification_id):
    """Delete a single notification"""
    notification = Notification.query.get_or_404(notification_id)
    
    if notification.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('notifications'))
    
    db.session.delete(notification)
    db.session.commit()
    flash('Notification deleted.', 'success')
    return redirect(url_for('notifications'))


@app.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    """Change password page"""
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Validation
        if not current_password or not new_password or not confirm_password:
            flash('All fields are required.', 'error')
            return render_template('change_password.html', customer=current_user)
        
        # Check current password
        if not current_user.check_password(current_password):
            flash('Current password is incorrect.', 'error')
            return render_template('change_password.html', customer=current_user)
        
        # Check if new password matches confirmation
        if new_password != confirm_password:
            flash('New passwords do not match.', 'error')
            return render_template('change_password.html', customer=current_user)
        
        # Check password length
        if len(new_password) < 6:
            flash('New password must be at least 6 characters long.', 'error')
            return render_template('change_password.html', customer=current_user)
        
        # Check if new password is different from current
        if current_user.check_password(new_password):
            flash('New password must be different from your current password.', 'error')
            return render_template('change_password.html', customer=current_user)
        
        # Update password
        try:
            current_user.set_password(new_password)
            db.session.commit()
            flash('Password changed successfully!', 'success')
            return redirect(url_for('profile'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while changing your password. Please try again.', 'error')
            return render_template('change_password.html', customer=current_user)
    
    return render_template('change_password.html', customer=current_user)


@app.route('/order/<int:order_id>/invoice')
@login_required
def download_invoice(order_id):
    """Generate and download invoice PDF"""
    order = Order.query.get_or_404(order_id)
    
    # Check if order belongs to current user
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    
    # Create PDF in memory
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
    
    # Container for the 'Flowable' objects
    elements = []
    
    # Styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#ff6b35'),
        spaceAfter=30,
        alignment=1  # Center
    )
    
    # Title
    title = Paragraph("INVOICE", title_style)
    elements.append(title)
    elements.append(Spacer(1, 0.2*inch))
    
    # Company and Customer Info
    company_info = f"""
    <b>ETR E-Commerce</b><br/>
    Email: {app.config['MAIL_DEFAULT_SENDER']}<br/>
    """
    
    customer_info = f"""
    <b>Bill To:</b><br/>
    {order.customer.first_name} {order.customer.last_name}<br/>
    {order.shipping_address}<br/>
    {order.shipping_city}, {order.shipping_state} {order.shipping_zip}<br/>
    {order.shipping_country}
    """
    
    info_table_data = [
        [Paragraph(company_info, styles['Normal']), Paragraph(customer_info, styles['Normal'])]
    ]
    info_table = Table(info_table_data, colWidths=[3*inch, 3*inch])
    info_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]))
    elements.append(info_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Order Details
    order_details = f"""
    <b>Order Number:</b> {order.order_number}<br/>
    <b>Order Date:</b> {order.created_at.strftime('%B %d, %Y')}<br/>
    <b>Payment Method:</b> {order.payment_method.replace('_', ' ').title()}<br/>
    <b>Status:</b> {order.status}
    """
    elements.append(Paragraph(order_details, styles['Normal']))
    elements.append(Spacer(1, 0.3*inch))
    
    # Items Table
    items_data = [['Item', 'Quantity', 'Unit Price', 'Total']]
    
    for item in order.items:
        items_data.append([
            item.product.name,
            str(item.quantity),
            f"₱{item.price:.2f}",
            f"₱{item.subtotal:.2f}"
        ])
    
    # Add subtotal, shipping, and total
    items_data.append(['', '', 'Subtotal:', f"₱{float(order.total_amount) - 8:.2f}"])
    items_data.append(['', '', 'Shipping Fee:', '₱8.00'])
    items_data.append(['', '', '<b>Total:</b>', f"<b>₱{order.total_amount:.2f}</b>"])
    
    items_table = Table(items_data, colWidths=[3*inch, 1*inch, 1.5*inch, 1.5*inch])
    items_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#ff6b35')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
        ('ALIGN', (2, 0), (-1, -1), 'RIGHT'),
        ('ALIGN', (3, 0), (-1, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -4), colors.beige),
        ('GRID', (0, 0), (-1, -4), 1, colors.grey),
        ('FONTNAME', (2, -3), (-1, -1), 'Helvetica-Bold'),
        ('TOPPADDING', (-2, -1), (-1, -1), 12),
        ('BOTTOMPADDING', (-2, -1), (-1, -1), 12),
    ]))
    elements.append(items_table)
    
    # Build PDF
    doc.build(elements)
    
    # Get PDF value
    buffer.seek(0)
    
    # Create response
    filename = f'invoice_{order.order_number}.pdf'
    return send_file(buffer, as_attachment=True, download_name=filename, mimetype='application/pdf')


def send_order_email(customer, order, email_type='order_placed'):
    """Send order notification email"""
    if not customer.email_notifications and email_type != 'payment_required':
        return
    
    try:
        if email_type == 'order_placed':
            subject = f'Order Confirmation - {order.order_number}'
            template = 'emails/order_placed.html'
        elif email_type == 'order_shipped':
            subject = f'Your Order Has Shipped - {order.order_number}'
            template = 'emails/order_shipped.html'
        elif email_type == 'order_delivered':
            subject = f'Order Delivered - {order.order_number}'
            template = 'emails/order_delivered.html'
        elif email_type == 'payment_verified':
            subject = f'Payment Verified - {order.order_number}'
            template = 'emails/payment_verified.html'
        else:
            return
        
        msg = Message(
            subject=subject,
            recipients=[customer.email],
            html=render_template(template, customer=customer, order=order)
        )
        
        if not app.config['MAIL_SUPPRESS_SEND']:
            mail.send(msg)
    except Exception as e:
        # Log error in production
        pass


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

