# MySQL Setup Guide for ETR E-Commerce

## Option 1: Install XAMPP (Easiest - Recommended)

1. **Download XAMPP:**
   - Go to: https://www.apachefriends.org/download.html
   - Download XAMPP for Windows
   - Install it (default location: C:\xampp)

2. **Start MySQL:**
   - Open XAMPP Control Panel
   - Click "Start" next to MySQL
   - Wait until status shows "Running"

3. **Create Database:**
   - Open browser and go to: http://localhost/phpmyadmin
   - Click "New" in the left sidebar
   - Database name: `etr_ecommerce`
   - Collation: `utf8mb4_unicode_ci`
   - Click "Create"

4. **Update app.py:**
   - Line 20: Change password if you set one during XAMPP installation
   - Default XAMPP MySQL: username=`root`, password=`` (empty)

## Option 2: Install MySQL Standalone

1. **Download MySQL:**
   - Go to: https://dev.mysql.com/downloads/mysql/
   - Download MySQL Installer for Windows
   - Run installer and follow setup wizard
   - Remember the root password you set!

2. **Start MySQL Service:**
   - Press Win+R, type `services.msc`
   - Find "MySQL80" or "MySQL"
   - Right-click → Start

3. **Create Database:**
   - Open MySQL Command Line Client
   - Enter your root password
   - Run: `CREATE DATABASE etr_ecommerce CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`

4. **Update app.py:**
   - Line 20: Update with your MySQL root password

## Option 3: Use Docker (Advanced)

```bash
docker run --name mysql-etr -e MYSQL_ROOT_PASSWORD=password -e MYSQL_DATABASE=etr_ecommerce -p 3306:3306 -d mysql:8.0
```

Then update app.py line 20 with: `mysql+pymysql://root:password@localhost:3306/etr_ecommerce`

