from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file, session, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_mail import Mail, Message
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadSignature
import os
from decimal import Decimal
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from io import BytesIO

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
default_db_uri = os.environ.get('DATABASE_URL')
if not default_db_uri:
    use_mysql = os.environ.get('USE_MYSQL', 'true').lower() == 'true'
    if use_mysql:
        mysql_user = os.environ.get('MYSQL_USER', 'root')
        mysql_password = os.environ.get('MYSQL_PASSWORD', '')
        mysql_host = os.environ.get('MYSQL_HOST', 'localhost')
        mysql_port = os.environ.get('MYSQL_PORT', '3306')
        mysql_db = os.environ.get('MYSQL_DATABASE', 'etr_ecommerce')
        if mysql_password:
            default_db_uri = f'mysql+pymysql://{mysql_user}:{mysql_password}@{mysql_host}:{mysql_port}/{mysql_db}'
        else:
            default_db_uri = f'mysql+pymysql://{mysql_user}@{mysql_host}:{mysql_port}/{mysql_db}'
    else:
        default_db_uri = 'sqlite:///etr_ecommerce.db'
app.config['SQLALCHEMY_DATABASE_URI'] = default_db_uri
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads/payments'
app.config['PROFILE_PICTURE_FOLDER'] = 'static/uploads/profiles'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
app.config['MAIL_PORT'] = int(os.environ.get('MAIL_PORT', 587))
app.config['MAIL_USE_TLS'] = os.environ.get('MAIL_USE_TLS', 'True').lower() in ['true', 'on', '1']
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', '')
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', '')
app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER', 'noreply@etr-ecommerce.com')
app.config['MAIL_SUPPRESS_SEND'] = os.environ.get('MAIL_SUPPRESS_SEND', 'False').lower() in ['true', 'on', '1']

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please sign in to access this page.'
login_manager.login_message_category = 'info'

mail = Mail(app)

password_reset_serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['PROFILE_PICTURE_FOLDER'], exist_ok=True)

app.jinja_env.globals['float'] = float


class Customer(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(100), nullable=False)
    middle_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(11))
    address = db.Column(db.Text)
    city = db.Column(db.String(100))
    state = db.Column(db.String(100))
    zip_code = db.Column(db.String(20))
    country = db.Column(db.String(100))
    gender = db.Column(db.String(10))
    date_of_birth = db.Column(db.Date)
    profile_picture_url = db.Column(db.String(255))
    email_notifications = db.Column(db.Boolean, default=True)
    order_updates = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    is_admin = db.Column(db.Boolean, default=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<Customer {self.username}>'

class Address(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    full_address = db.Column(db.Text, nullable=False)
    city = db.Column(db.String(100), nullable=False)
    state = db.Column(db.String(100))
    zip_code = db.Column(db.String(20))
    country = db.Column(db.String(100), default='Philippines')
    is_default = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    customer = db.relationship('Customer', backref='addresses')

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    stock = db.Column(db.Integer, default=0)
    image_url = db.Column(db.String(500))
    brand = db.Column(db.String(100))
    sku = db.Column(db.String(100), unique=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Product {self.name}>'


class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    customer = db.relationship('Customer', backref='cart_items')
    product = db.relationship('Product', backref='cart_items')
    def __repr__(self):
        return f'<Cart {self.customer_id} - {self.product_id}>'


class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_number = db.Column(db.String(50), unique=True, nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    total_amount = db.Column(db.Numeric(10, 2), nullable=False)
    status = db.Column(db.String(20), default='Pending', nullable=False)
    payment_method = db.Column(db.String(50), nullable=False)
    payment_status = db.Column(db.String(20), default='Pending')
    shipping_address = db.Column(db.Text, nullable=False)
    shipping_city = db.Column(db.String(100), nullable=False)
    shipping_state = db.Column(db.String(100))
    shipping_zip = db.Column(db.String(20))
    shipping_country = db.Column(db.String(100))
    decline_reason = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    customer = db.relationship('Customer', backref='orders')
    items = db.relationship('OrderItem', backref='order', cascade='all, delete-orphan')
    payment = db.relationship('Payment', backref='order', uselist=False)
    def __repr__(self):
        return f'<Order {self.order_number}>'


class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    subtotal = db.Column(db.Numeric(10, 2), nullable=False)
    product = db.relationship('Product', backref='order_items')
    def __repr__(self):
        return f'<OrderItem {self.id}>'


class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False, unique=True)
    payment_method = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    proof_image = db.Column(db.String(500))
    status = db.Column(db.String(20), default='Pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    def __repr__(self):
        return f'<Payment {self.id}>'


class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=True)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(50), nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    customer = db.relationship('Customer', backref='notifications')
    order = db.relationship('Order', backref='notifications')
    def __repr__(self):
        return f'<Notification {self.id}>'


class PasswordResetToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    token = db.Column(db.String(255), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False)
    customer = db.relationship('Customer', backref='password_reset_tokens')
    def is_valid(self):
        return not self.used and datetime.utcnow() < self.expires_at
    def __repr__(self):
        return f'<PasswordResetToken {self.id}>'


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(Customer, int(user_id))


@app.context_processor
def inject_cart_count():
    if current_user.is_authenticated:
        cart_count = Cart.query.filter_by(customer_id=current_user.id).count()
        return {'cart_count': cart_count}
    return {'cart_count': 0}


@app.route('/')
def index():
    best_products = Product.query.filter_by(is_active=True).order_by(Product.created_at.desc()).limit(4).all()
    return render_template('index.html', best_products=best_products)


@app.route('/about-us')
def about_us():
    return render_template('about_us.html')


@app.route('/blog')
def blog():
    return render_template('blog.html')


@app.route('/contact-us', methods=['GET', 'POST'])
def contact_us():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        if not all([name, email, subject, message]):
            flash('Please fill in all fields.', 'error')
            return render_template('contact_us.html')
        flash('Thank you for contacting us! We will get back to you soon.', 'success')
        return redirect(url_for('contact_us'))
    return render_template('contact_us.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        first_name = request.form.get('first_name')
        middle_name = request.form.get('middle_name', '')
        last_name = request.form.get('last_name')
        phone = request.form.get('phone', '')
        address = request.form.get('address', '')
        city = request.form.get('city', '')
        state = request.form.get('state', '')
        zip_code = request.form.get('zip_code', '')
        country = request.form.get('country', '')

        errors = []
        if not username or not email or not password:
            errors.append('Username, email, and password are required.')
        if password != confirm_password:
            errors.append('Passwords do not match.')
        if len(password) < 6:
            errors.append('Password must be at least 6 characters long.')
        if Customer.query.filter_by(username=username).first():
            errors.append('Username already exists. Please choose a different one.')
        if Customer.query.filter_by(email=email).first():
            errors.append('Email already registered. Please use a different email.')
        if phone:
            phone_clean = ''.join(filter(str.isdigit, phone))
            if not phone_clean.startswith('09'):
                errors.append('Phone number must start with 09 (Philippines format).')
            elif len(phone_clean) != 11:
                errors.append('Phone number must be exactly 11 digits starting with 09 (e.g., 09123456789).')
            else:
                phone = phone_clean

        if errors:
            for error in errors:
                flash(error, 'error')
            return render_template('register.html')

        try:
            customer = Customer(
                username=username,
                email=email,
                first_name=first_name,
                middle_name=middle_name if middle_name else None,
                last_name=last_name,
                phone=phone,
                address=address,
                city=city,
                state=state,
                zip_code=zip_code,
                country=country
            )
            customer.set_password(password)
            db.session.add(customer)
            db.session.flush()
            if address and (city or state):
                address_city = city if city else state
                address_entry = Address(
                    customer_id=customer.id,
                    full_address=address,
                    city=address_city,
                    state=state if city else '',
                    zip_code=zip_code or '',
                    country=country or 'Philippines',
                    is_default=True
                )
                db.session.add(address_entry)
            db.session.commit()
            flash('Sign up successful! Please sign in.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred during registration. Please try again.', 'error')
            return render_template('register.html')

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password', '')
        remember = bool(request.form.get('remember'))

        if not username:
            flash('Please enter username.', 'error')
            return render_template('login.html')

        customer = Customer.query.filter_by(username=username).first()

        if customer:
            if customer.is_admin:
                if not password or password.strip() == '':
                    if not customer.is_active:
                        flash('Your account has been deactivated. Please contact support.', 'error')
                        return render_template('login.html')
                    login_user(customer, remember=remember)
                    next_page = request.args.get('next')
                    flash(f'Welcome back, Admin {customer.first_name}!', 'success')
                    if next_page:
                        return redirect(next_page)
                    return redirect(url_for('admin_dashboard'))
                else:
                    if customer.check_password(password):
                        if not customer.is_active:
                            flash('Your account has been deactivated. Please contact support.', 'error')
                            return render_template('login.html')
                        login_user(customer, remember=remember)
                        next_page = request.args.get('next')
                        flash(f'Welcome back, Admin {customer.first_name}!', 'success')
                        if next_page:
                            return redirect(next_page)
                        return redirect(url_for('admin_dashboard'))
                    else:
                        flash('Invalid password.', 'error')
                        return render_template('login.html')
            else:
                if not password:
                    flash('Please enter password.', 'error')
                    return render_template('login.html')
                if customer.check_password(password):
                    if not customer.is_active:
                        flash('Your account has been deactivated. Please contact support.', 'error')
                        return render_template('login.html')
                    login_user(customer, remember=remember)
                    next_page = request.args.get('next')
                    flash(f'Welcome back, {customer.first_name}!', 'success')
                    return redirect(next_page) if next_page else redirect(url_for('index'))
                else:
                    flash('Invalid username or password.', 'error')
        else:
            flash('Invalid username or password.', 'error')

    return render_template('login.html')


@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        if not email:
            flash('Please enter your email address.', 'error')
            return render_template('forgot_password.html')
        customer = Customer.query.filter_by(email=email).first()
        if customer:
            token = password_reset_serializer.dumps(email, salt='password-reset-salt')
            expires_at = datetime.utcnow() + timedelta(hours=1)
            reset_token = PasswordResetToken(
                customer_id=customer.id,
                token=token,
                expires_at=expires_at
            )
            db.session.add(reset_token)
            db.session.commit()
            reset_url = url_for('reset_password', token=token, _external=True)
            try:
                msg = Message(
                    subject='Password Reset Request - ETR E-Commerce',
                    recipients=[customer.email],
                    html=render_template('emails/password_reset.html', 
                                       customer=customer, 
                                       reset_url=reset_url)
                )
                if not app.config['MAIL_SUPPRESS_SEND']:
                    mail.send(msg)
                flash('Password reset link has been sent to your email address.', 'success')
            except Exception as e:
                flash('Password reset link has been sent to your email address.', 'success')
        else:
            flash('If an account exists with that email, a password reset link has been sent.', 'success')
        return redirect(url_for('login'))
    return render_template('forgot_password.html')


@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    try:
        email = password_reset_serializer.loads(token, salt='password-reset-salt', max_age=3600)
    except (SignatureExpired, BadSignature):
        flash('Invalid or expired password reset link. Please request a new one.', 'error')
        return redirect(url_for('forgot_password'))
    reset_token = PasswordResetToken.query.filter_by(token=token).first()
    if not reset_token or not reset_token.is_valid():
        flash('Invalid or expired password reset link. Please request a new one.', 'error')
        return redirect(url_for('forgot_password'))
    customer = Customer.query.filter_by(email=email).first()
    if not customer:
        flash('Invalid password reset link.', 'error')
        return redirect(url_for('forgot_password'))
    if request.method == 'POST':
        new_password = request.form.get('new_password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()
        if not new_password or not confirm_password:
            flash('Please fill in all fields.', 'error')
            return render_template('reset_password.html', token=token)
        if new_password != confirm_password:
            flash('Passwords do not match.', 'error')
            return render_template('reset_password.html', token=token)
        if len(new_password) < 6:
            flash('Password must be at least 6 characters long.', 'error')
            return render_template('reset_password.html', token=token)
        try:
            customer.set_password(new_password)
            reset_token.used = True
            db.session.commit()
            flash('Your password has been reset successfully. Please login with your new password.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while resetting your password. Please try again.', 'error')
            return render_template('reset_password.html', token=token)
    return render_template('reset_password.html', token=token)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('index'))


@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        customer = current_user
        if 'first_name' in request.form:
            customer.first_name = request.form.get('first_name', '').strip()
        if 'last_name' in request.form:
            customer.last_name = request.form.get('last_name', '').strip()
        if 'email' in request.form:
            new_email = request.form.get('email', '').strip()
            if not new_email:
                flash('Email is required.', 'error')
                return redirect(url_for('profile'))
            if new_email != customer.email:
                existing_customer = Customer.query.filter_by(email=new_email).first()
                if existing_customer and existing_customer.id != customer.id:
                    flash('Email already registered. Please use a different email.', 'error')
                    return redirect(url_for('profile'))
                customer.email = new_email
        if 'phone' in request.form:
            phone = request.form.get('phone', '').strip()
            if phone:
                phone_clean = ''.join(filter(str.isdigit, phone))
                if not phone_clean.startswith('09'):
                    flash('Phone number must start with 09 (Philippines format).', 'error')
                    return redirect(url_for('profile'))
                elif len(phone_clean) != 11:
                    flash('Phone number must be exactly 11 digits starting with 09 (e.g., 09123456789).', 'error')
                    return redirect(url_for('profile'))
                else:
                    customer.phone = phone_clean
            else:
                customer.phone = None
        if 'gender' in request.form:
            customer.gender = request.form.get('gender') or None
        if not customer.date_of_birth:
            if 'birth_day' in request.form and 'birth_month' in request.form and 'birth_year' in request.form:
                day = request.form.get('birth_day')
                month = request.form.get('birth_month')
                year = request.form.get('birth_year')
                if day and month and year:
                    try:
                        customer.date_of_birth = datetime(int(year), int(month), int(day)).date()
                    except ValueError:
                        flash('Invalid date of birth', 'error')
        if 'profile_picture' in request.files:
            file = request.files['profile_picture']
            if file and file.filename:
                if allowed_file(file.filename):
                    os.makedirs(app.config['PROFILE_PICTURE_FOLDER'], exist_ok=True)
                    filename = secure_filename(f"{customer.id}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{file.filename}")
                    filepath = os.path.join(app.config['PROFILE_PICTURE_FOLDER'], filename)
                    file.save(filepath)
                    file_size = os.path.getsize(filepath)
                    if file_size > 1024 * 1024:
                        os.remove(filepath)
                        flash('File size exceeds 1 MB. Please upload a smaller image.', 'error')
                    else:
                        customer.profile_picture_url = f"uploads/profiles/{filename}"
                else:
                    flash('Invalid file type. Please upload JPEG or PNG image.', 'error')
        try:
            db.session.commit()
            flash('Profile updated successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash('Error updating profile. Please try again.', 'error')
        return redirect(url_for('profile'))
    return render_template('profile.html', customer=current_user)

@app.route('/addresses', methods=['GET', 'POST'])
@login_required
def addresses():
    if request.method == 'POST':
        address = Address(
            customer_id=current_user.id,
            full_address=request.form['full_address'],
            city=request.form['city'],
            state=request.form.get('state', ''),
            zip_code=request.form.get('zip_code', ''),
            country=request.form.get('country', 'Philippines')
        )

        if not Address.query.filter_by(customer_id=current_user.id).count():
            address.is_default = True

        db.session.add(address)
        db.session.commit()
        flash('Address added successfully!', 'success')
        return redirect(url_for('addresses'))

    existing_addresses = Address.query.filter_by(customer_id=current_user.id).all()
    if not existing_addresses and current_user.address and (current_user.city or current_user.state):
        address_city = current_user.city if current_user.city else current_user.state
        address_entry = Address(
            customer_id=current_user.id,
            full_address=current_user.address,
            city=address_city,
            state=current_user.state if current_user.city else '',
            zip_code=current_user.zip_code or '',
            country=current_user.country or 'Philippines',
            is_default=True
        )
        db.session.add(address_entry)
        db.session.commit()
        existing_addresses = Address.query.filter_by(customer_id=current_user.id).all()
    return render_template('addresses.html', addresses=existing_addresses)

@app.route('/addresses/set-default/<int:address_id>', methods=['POST'])
@login_required
def set_default_address(address_id):
    Address.query.filter_by(customer_id=current_user.id).update({'is_default': False})
    address = Address.query.get_or_404(address_id)
    address.is_default = True
    db.session.commit()
    flash('Default address updated!', 'success')
    return redirect(url_for('addresses'))
@app.route('/addresses/edit/<int:address_id>', methods=['POST'])
@login_required
def edit_address(address_id):
    address = Address.query.get_or_404(address_id)

    if address.customer_id != current_user.id:
        abort(403)

    address.full_address = request.form['full_address']
    address.city = request.form['city']
    address.state = request.form.get('state', '')
    address.zip_code = request.form.get('zip_code', '')
    address.country = request.form.get('country', 'Philippines')

    db.session.commit()
    flash('Address updated!', 'success')
    return redirect(url_for('addresses'))
@app.route('/addresses/delete/<int:address_id>', methods=['POST'])
@login_required
def delete_address(address_id):
    address = Address.query.get_or_404(address_id)

    if address.customer_id != current_user.id:
        abort(403)

    db.session.delete(address)
    db.session.commit()
    flash('Address deleted!', 'info')
    return redirect(url_for('addresses'))

@app.route('/products')
def products():
    search = request.args.get('search', '').strip()
    category = request.args.get('category', '').strip()
    min_price = request.args.get('min_price', '')
    max_price = request.args.get('max_price', '')
    sort_by = request.args.get('sort', 'name')
    query = Product.query.filter_by(is_active=True)
    if search:
        query = query.filter(
            db.or_(
                Product.name.ilike(f'%{search}%'),
                Product.description.ilike(f'%{search}%'),
                Product.brand.ilike(f'%{search}%')
            )
        )
    if category:
        query = query.filter_by(category=category)
    if min_price:
        try:
            min_price_float = float(min_price)
            query = query.filter(Product.price >= min_price_float)
        except ValueError:
            pass
    if max_price:
        try:
            max_price_float = float(max_price)
            query = query.filter(Product.price <= max_price_float)
        except ValueError:
            pass
    if sort_by == 'price_low':
        query = query.order_by(Product.price.asc())
    elif sort_by == 'price_high':
        query = query.order_by(Product.price.desc())
    else:
        query = query.order_by(Product.name.asc())
    products = query.all()
    categories = db.session.query(Product.category).distinct().all()
    categories = [cat[0] for cat in categories if cat[0]]
    return render_template(
        'products.html',
        products=products,
        categories=categories,
        search=search,
        selected_category=category,
        min_price=min_price,
        max_price=max_price,
        sort_by=sort_by
    )


@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    if not product.is_active:
        flash('This product is no longer available.', 'error')
        return redirect(url_for('products'))
    related_products = Product.query.filter(
        Product.category == product.category,
        Product.id != product.id,
        Product.is_active == True
    ).limit(4).all()
    return render_template('product_detail.html', product=product, related_products=related_products)


@app.route('/seed-products')
def seed_products():
    try:
        deleted_count = Product.query.delete()
        db.session.commit()
        if deleted_count > 0:
            flash(f'Cleared {deleted_count} existing products.', 'info')
    except Exception as e:
        db.session.rollback()
        flash(f'Error clearing products: {str(e)}', 'error')
    sample_products = [
        {
            'name': 'Wireless Bluetooth Headphones',
            'description': 'High-quality wireless headphones with noise cancellation and 30-hour battery life. Perfect for music lovers and professionals.',
            'price': 2999.99,
            'category': 'Electronics',
            'stock': 50,
            'brand': 'AudioTech',
            'sku': 'ATH-WB-001',
            'image_url': 'images/products/Wirelessbluetoothheadphones.jpg'
        },
        {
            'name': 'Smartphone 128GB',
            'description': 'Latest smartphone with 128GB storage, triple camera system, and fast charging. Available in multiple colors.',
            'price': 24999.99,
            'category': 'Electronics',
            'stock': 25,
            'brand': 'Samsung',
            'sku': 'TP-SM-128',
            'image_url': 'images/products/smartP.jpg'
        },
        {
            'name': 'Wireless Mouse',
            'description': 'Ergonomic wireless mouse with long battery life and precise tracking. Compatible with all operating systems.',
            'price': 599.99,
            'category': 'Electronics',
            'stock': 80,
            'brand': 'LogiTech',
            'sku': 'TM-WM-001',
            'image_url': 'images/products/wmouse.jpg'
        },
        {
            'name': 'Gaming Keyboard',
            'description': 'Mechanical gaming keyboard with RGB backlighting and programmable keys. Perfect for gamers.',
            'price': 4499.99,
            'category': 'Electronics',
            'stock': 35,
            'brand': 'LogiTech',
            'sku': 'GT-GK-001',
            'image_url': 'images/products/keyb.jpg'
        },
        {
            'name': 'Smart Watch Pro',
            'description': 'Feature-rich smartwatch with fitness tracking, heart rate monitor, GPS, and 7-day battery life. Water-resistant design.',
            'price': 8999.99,
            'category': 'Electronics',
            'stock': 30,
            'brand': 'AppleStore',
            'sku': 'TW-SW-001',
            'image_url': 'images/products/smartW.jpg'
        },
        {
            'name': '4K Ultra HD TV 55"',
            'description': '55-inch 4K Ultra HD Smart TV with HDR support, built-in streaming apps, and voice control. Perfect for home entertainment.',
            'price': 34999.99,
            'category': 'Electronics',
            'stock': 15,
            'brand': 'Life Good',
            'sku': 'VT-TV-55',
            'image_url': 'images/products/tv.jpg'
        },
        {
            'name': 'Cotton T-Shirt',
            'description': 'Comfortable 100% cotton t-shirt. Available in various sizes and colors. Perfect for everyday wear.',
            'price': 499.99,
            'category': 'Clothing',
            'stock': 100,
            'brand': 'MNL-Clothing',
            'sku': 'FW-TS-001',
            'image_url': 'images/products/tshirt.jpg'
        },
        {
            'name': 'Denim Jeans',
            'description': 'Classic fit denim jeans made from premium cotton. Available in various sizes and washes.',
            'price': 1299.99,
            'category': 'Clothing',
            'stock': 55,
            'brand': 'MNL-Clothing',
            'sku': 'FW-DJ-001',
            'image_url': 'images/products/jeans.jpg'
        },
        {
            'name': 'Hooded Sweatshirt',
            'description': 'Warm and comfortable hooded sweatshirt with front pocket. Perfect for casual wear and outdoor activities.',
            'price': 1499.99,
            'category': 'Clothing',
            'stock': 65,
            'brand': 'ComfortWear',
            'sku': 'CW-HS-001',
            'image_url': 'images/products/hood.jpg'
        },
        {
            'name': 'Polo Shirt',
            'description': 'Classic polo shirt made from breathable cotton blend. Perfect for business casual or weekend wear.',
            'price': 799.99,
            'category': 'Clothing',
            'stock': 70,
            'brand': 'HUILISHI',
            'sku': 'SW-PS-001',
            'image_url': 'images/products/poloS.jpg'
        },
        {
            'name': 'Summer Dress',
            'description': 'Lightweight and elegant summer dress with floral pattern. Perfect for warm weather and special occasions.',
            'price': 1899.99,
            'category': 'Clothing',
            'stock': 40,
            'brand': 'Elegance',
            'sku': 'EL-SD-001',
            'image_url': 'images/products/summerD.jpg'
        },
        {
            'name': 'Leather Jacket',
            'description': 'Genuine leather jacket with classic design. Durable and stylish, perfect for all seasons.',
            'price': 5999.99,
            'category': 'Clothing',
            'stock': 20,
            'brand': 'MNL-Clothing',
            'sku': 'LC-LJ-001',
            'image_url': 'images/products/letherJack.jpg'
        },
        {
            'name': 'Running Shoes',
            'description': 'Lightweight running shoes with cushioned sole and breathable mesh upper. Ideal for jogging and sports.',
            'price': 3499.99,
            'category': 'Footwear',
            'stock': 40,
            'brand': 'SportCenter',
            'sku': 'SM-RS-001',
            'image_url': 'images/products/nikeS.jpg'
        },
        {
            'name': 'Casual Sneakers',
            'description': 'Comfortable casual sneakers with modern design. Perfect for everyday wear and walking.',
            'price': 2499.99,
            'category': 'Footwear',
            'stock': 50,
            'brand': 'SportCenter',
            'sku': 'CS-CS-001',
            'image_url': 'images/products/Sneak.jpg'
        },
        {
            'name': 'Leather Shoes',
            'description': 'Elegant leather dress shoes with classic design. Perfect for formal occasions and business wear.',
            'price': 2799.99,
            'category': 'Footwear',
            'stock': 30,
            'brand': 'Bragais',
            'sku': 'FS-LDS-001',
            'image_url': 'images/products/lshoes.jpg'
        },
        {
            'name': 'Hiking Boots',
            'description': 'Durable hiking boots with waterproof membrane and superior grip. Perfect for outdoor adventures.',
            'price': 1999,
            'category': 'Footwear',
            'stock': 25,
            'brand': 'AdventureFoot',
            'sku': 'AF-HB-001',
            'image_url': 'images/products/hikingSh.jpg'
        },
        {
            'name': 'Sandals',
            'description': 'Comfortable sandals with adjustable straps and cushioned footbed. Perfect for summer and beach.',
            'price': 899,
            'category': 'Footwear',
            'stock': 60,
            'brand': 'SummerStep',
            'sku': 'SS-SD-001',
            'image_url': 'images/products/sandal.jpg'
        },
        {
            'name': 'Basketball Shoes',
            'description': 'High-performance basketball shoes with excellent ankle support and superior traction. Designed for athletes.',
            'price': 5499.99,
            'category': 'Footwear',
            'stock': 35,
            'brand': 'SportCenter',
            'sku': 'SM-BS-001',
            'image_url': 'images/products/lebronS.jpg'
        },
        {
            'name': 'Laptop Backpack',
            'description': 'Durable laptop backpack with padded compartment for laptops up to 15.6 inches. Multiple pockets for organization.',
            'price': 1299.99,
            'category': 'Accessories',
            'stock': 60,
            'brand': 'TravelGear',
            'sku': 'TG-LB-001',
            'image_url': 'images/products/laptopB.jpg'
        },
        {
            'name': 'Leather Wallet',
            'description': 'Genuine leather wallet with multiple card slots and cash compartment. Classic design.',
            'price': 799,
            'category': 'Accessories',
            'stock': 45,
            'brand': 'LeatherCraft',
            'sku': 'LC-WL-001',
            'image_url': 'images/products/walletL.jpg'
        },
        {
            'name': 'Stainless Steel Water Bottle',
            'description': 'Insulated stainless steel water bottle keeps drinks cold for 24 hours or hot for 12 hours. BPA-free.',
            'price': 699,
            'category': 'Accessories',
            'stock': 90,
            'brand': 'EcoBottle',
            'sku': 'EB-WB-001',
            'image_url': 'images/products/tumbler.jpg'
        },
        {
            'name': 'Sunglasses',
            'description': 'Stylish sunglasses with UV400 protection and polarized lenses. Available in multiple frame colors.',
            'price': 1299.99,
            'category': 'Accessories',
            'stock': 55,
            'brand': 'Dior',
            'sku': 'SS-SG-001',
            'image_url': 'images/products/Iglases.jpg'
        },
        {
            'name': 'Leather Belt',
            'description': 'Genuine leather belt with classic buckle design. Adjustable size to fit various waist sizes.',
            'price': 299,
            'category': 'Accessories',
            'stock': 50,
            'brand': 'LeatherCraft',
            'sku': 'LC-LB-001',
            'image_url': 'images/products/belts.jpg'
        },
        {
            'name': 'Smartphone Case',
            'description': 'Protective smartphone case with shock-absorbing design. Available for various phone models.',
            'price': 399,
            'category': 'Accessories',
            'stock': 120,
            'brand': 'ProtectTech',
            'sku': 'PT-SC-001',
            'image_url': 'images/products/case.jpg'
        },
        {
            'name': 'Coffee Maker',
            'description': 'Programmable coffee maker with 12-cup capacity. Auto shut-off and brew strength control.',
            'price': 14999.99,
            'category': 'Home & Kitchen',
            'stock': 30,
            'brand': 'BrewMaster',
            'sku': 'BM-CM-001',
            'image_url': 'images/products/CM.jpg'
        },
        {
            'name': 'Air Fryer',
            'description': 'Digital air fryer with large capacity. Cook healthier meals with less oil. Easy to clean and use.',
            'price': 4999.99,
            'category': 'Home & Kitchen',
            'stock': 25,
            'brand': 'KitchenPro',
            'sku': 'KP-AF-001',
            'image_url': 'images/products/airf.jpg'
        },
        {
            'name': 'Blender',
            'description': 'High-speed blender with multiple settings. Perfect for smoothies, soups, and sauces. Easy to clean.',
            'price': 1499.99,
            'category': 'Home & Kitchen',
            'stock': 35,
            'brand': 'BlendTech',
            'sku': 'BT-BL-001',
            'image_url': 'images/products/blender.jpg'
        },
        {
            'name': 'Dinnerware Set',
            'description': 'Complete dinnerware set for 6 people. Includes plates, bowls, and mugs. Dishwasher safe and durable.',
            'price': 1499.99,
            'category': 'Home & Kitchen',
            'stock': 40,
            'brand': 'HomeStyle',
            'sku': 'HS-DS-001',
            'image_url': 'images/products/dinnerSet.jpg'
        },
        {
            'name': 'Cookware Set',
            'description': 'Non-stick cookware set with 10 pieces. Includes various pots and pans. Oven safe up to 400°F.',
            'price': 5999.99,
            'category': 'Home & Kitchen',
            'stock': 20,
            'brand': 'ChefPro',
            'sku': 'CP-CS-001',
            'image_url': 'images/products/cookset.jpg'
        },
        {
            'name': 'Stand Mixer',
            'description': 'Powerful stand mixer with multiple attachments. Perfect for baking and mixing. Includes dough hook and whisk.',
            'price': 6999.99,
            'category': 'Home & Kitchen',
            'stock': 15,
            'brand': 'BakeMaster',
            'sku': 'BM-SM-001',
            'image_url': 'images/products/KT.jpg'
        },
        {
            'name': 'Yoga Mat',
            'description': 'Non-slip yoga mat with extra cushioning. Perfect for yoga, pilates, and exercise routines.',
            'price': 199.99,
            'category': 'Sports & Fitness',
            'stock': 75,
            'brand': 'FitLife',
            'sku': 'FL-YM-001',
            'image_url': 'images/products/yogaM.jpg'
        },
        {
            'name': 'Dumbbell Set',
            'description': 'Adjustable dumbbell set with weights from 5kg to 25kg. Perfect for home workouts and strength training.',
            'price': 1099.99,
            'category': 'Sports & Fitness',
            'stock': 20,
            'brand': 'PowerFit',
            'sku': 'PF-DS-001',
            'image_url': 'images/products/dumpbell.jpg'
        },
        {
            'name': 'Resistance Bands Set',
            'description': 'Complete resistance bands set with 5 different resistance levels. Includes door anchor and exercise guide.',
            'price': 299.99,
            'category': 'Sports & Fitness',
            'stock': 50,
            'brand': 'FlexBand',
            'sku': 'FB-RS-001',
            'image_url': 'images/products/resistance.jpg'
        },
        {
            'name': 'Jump Rope',
            'description': 'Professional speed jump rope with adjustable length. Perfect for cardio workouts and weight loss.',
            'price': 199.99,
            'category': 'Sports & Fitness',
            'stock': 80,
            'brand': 'SpeedJump',
            'sku': 'SJ-JR-001',
            'image_url': 'images/products/jumprope.jpg'
        },
        {
            'name': 'Foam Roller',
            'description': 'High-density foam roller for muscle recovery and massage. Helps reduce muscle soreness and improve flexibility.',
            'price': 299.99,
            'category': 'Sports & Fitness',
            'stock': 45,
            'brand': 'RecoveryPro',
            'sku': 'RP-FR-001',
            'image_url': 'images/products/roler.jpg'
        },
        {
            'name': 'Exercise Bike',
            'description': 'Indoor exercise bike with adjustable resistance and digital display. Perfect for home cardio workouts.',
            'price': 12999.99,
            'category': 'Sports & Fitness',
            'stock': 10,
            'brand': 'CardioFit',
            'sku': 'CF-EB-001',
            'image_url': 'images/products/bike.jpg'
        },
        {
            'name': 'Laptop 15.6"',
            'description': 'High-performance laptop with 15.6-inch display, 16GB RAM, and 512GB SSD. Perfect for work and gaming.',
            'price': 49999.99,
            'category': 'Electronics',
            'stock': 20,
            'brand': 'TechPro',
            'sku': 'TP-LP-001',
            'image_url': 'images/products/laptop.jpg'
        },
        {
            'name': 'Wireless Earbuds',
            'description': 'True wireless earbuds with noise cancellation and 8-hour battery life. Perfect for music and calls.',
            'price': 1999.99,
            'category': 'Electronics',
            'stock': 60,
            'brand': 'AudioTech',
            'sku': 'ATH-WE-001',
            'image_url': 'images/products/wirelessearbdus.jpg'
        },
        {
            'name': 'Tablet 10.1"',
            'description': '10.1-inch tablet with high-resolution display and long battery life. Perfect for reading and entertainment.',
            'price': 14999.99,
            'category': 'Electronics',
            'stock': 30,
            'brand': 'TechPro',
            'sku': 'TP-TB-001',
            'image_url': 'images/products/tablet.jpg'
        },
        {
            'name': 'Portable Speaker',
            'description': 'Bluetooth portable speaker with 360-degree sound and waterproof design. Perfect for outdoor activities.',
            'price': 2499.99,
            'category': 'Electronics',
            'stock': 45,
            'brand': 'SoundMax',
            'sku': 'SM-PS-001',
            'image_url': 'images/products/speaker.jpg'
        },
        {
            'name': 'Action Camera',
            'description': '4K action camera with waterproof case and image stabilization. Perfect for sports and adventures.',
            'price': 8999.99,
            'category': 'Electronics',
            'stock': 25,
            'brand': 'ActionCam',
            'sku': 'AC-CM-001',
            'image_url': 'images/products/actioncam.jpg'
        },
        {
            'name': 'Winter Jacket',
            'description': 'Warm winter jacket with water-resistant outer shell and insulated lining. Perfect for cold weather.',
            'price': 3999.99,
            'category': 'Clothing',
            'stock': 35,
            'brand': 'WarmWear',
            'sku': 'WW-WJ-001',
            'image_url': 'images/products/winterjacket.jpg'
        },
        {
            'name': 'Formal Shirt',
            'description': 'Classic formal dress shirt made from premium cotton. Perfect for business and formal occasions.',
            'price': 1299.99,
            'category': 'Clothing',
            'stock': 50,
            'brand': 'FormalWear',
            'sku': 'FW-FS-001',
            'image_url': 'images/products/formalshirt.jpg'
        },
        {
            'name': 'Athletic Shorts',
            'description': 'Comfortable athletic shorts with moisture-wicking fabric. Perfect for sports and workouts.',
            'price': 599.99,
            'category': 'Clothing',
            'stock': 80,
            'brand': 'SportWear',
            'sku': 'SW-AS-001',
            'image_url': 'images/products/athleticshorts.jpg'
        },
        {
            'name': 'Cardigan Sweater',
            'description': 'Soft cardigan sweater with button front. Perfect for layering in cool weather.',
            'price': 1799.99,
            'category': 'Clothing',
            'stock': 40,
            'brand': 'ComfortWear',
            'sku': 'CW-CS-001',
            'image_url': 'images/products/cardigansweater.jpg'
        },
        {
            'name': 'Tank Top',
            'description': 'Comfortable tank top made from breathable cotton. Perfect for summer and casual wear.',
            'price': 399.99,
            'category': 'Clothing',
            'stock': 90,
            'brand': 'MNL-Clothing',
            'sku': 'FW-TT-001',
            'image_url': 'images/products/tank.jpg'
        },
        {
            'name': 'Wristwatch',
            'description': 'Classic analog wristwatch with leather strap. Water-resistant and elegant design.',
            'price': 1999.99,
            'category': 'Accessories',
            'stock': 40,
            'brand': 'TimeCraft',
            'sku': 'TC-WW-001',
            'image_url': 'images/products/Wristwatch.jpg'
        },
        {
            'name': 'Necklace',
            'description': 'Elegant silver necklace with pendant. Perfect gift for special occasions.',
            'price': 1499.99,
            'category': 'Accessories',
            'stock': 35,
            'brand': 'JewelCraft',
            'sku': 'JC-NK-001',
            'image_url': 'images/products/Necklace.jpg'
        },
        {
            'name': 'Baseball Cap',
            'description': 'Classic baseball cap with adjustable strap. Perfect for sun protection and casual style.',
            'price': 499.99,
            'category': 'Accessories',
            'stock': 70,
            'brand': 'CapStyle',
            'sku': 'CS-BC-001',
            'image_url': 'images/products/bccs.jpg'
        },
        {
            'name': 'Travel Bag',
            'description': 'Durable travel bag with multiple compartments and wheels. Perfect for trips and vacations.',
            'price': 3499.99,
            'category': 'Accessories',
            'stock': 30,
            'brand': 'TravelGear',
            'sku': 'TG-TB-001',
            'image_url': 'images/products/Travel Bag.jpg'
        },
        {
            'name': 'Scarf',
            'description': 'Soft and warm scarf made from premium materials. Perfect for winter fashion.',
            'price': 699.99,
            'category': 'Accessories',
            'stock': 55,
            'brand': 'WarmStyle',
            'sku': 'WS-SC-001',
            'image_url': 'images/products/scarf.jpg'
        },
        {
            'name': 'Microwave Oven',
            'description': 'Compact microwave oven with multiple cooking modes and defrost function. Perfect for quick meals.',
            'price': 3999.99,
            'category': 'Home & Kitchen',
            'stock': 25,
            'brand': 'KitchenPro',
            'sku': 'KP-MO-001',
            'image_url': 'images/products/moo.jpg'
        },
        {
            'name': 'Toaster',
            'description': '4-slice toaster with multiple browning settings and bagel mode. Perfect for breakfast.',
            'price': 1499.99,
            'category': 'Home & Kitchen',
            'stock': 40,
            'brand': 'KitchenPro',
            'sku': 'KP-TO-001',
            'image_url': 'images/products/Toaster.jpg'
        },
        {
            'name': 'Cutlery Set',
            'description': 'Stainless steel cutlery set for 8 people. Includes knives, forks, and spoons. Dishwasher safe.',
            'price': 999.99,
            'category': 'Home & Kitchen',
            'stock': 50,
            'brand': 'HomeStyle',
            'sku': 'HS-CS-001',
            'image_url': 'images/products/css.jpg'
        },
        {
            'name': 'Bedding Set',
            'description': 'Complete bedding set including sheets, pillowcases, and comforter. Soft and comfortable materials.',
            'price': 2499.99,
            'category': 'Home & Kitchen',
            'stock': 30,
            'brand': 'ComfortHome',
            'sku': 'CH-BS-001',
            'image_url': 'images/products/bss.jpg'
        },
        {
            'name': 'Vacuum Cleaner',
            'description': 'Powerful vacuum cleaner with HEPA filter and multiple attachments. Perfect for home cleaning.',
            'price': 5999.99,
            'category': 'Home & Kitchen',
            'stock': 20,
            'brand': 'CleanPro',
            'sku': 'CP-VC-001',
            'image_url': 'images/products/vc.jpg'
        },
        {
            'name': 'Rice Cooker',
            'description': 'Automatic rice cooker with keep-warm function and multiple cooking modes. Perfect for daily meals.',
            'price': 1999.99,
            'category': 'Home & Kitchen',
            'stock': 35,
            'brand': 'KitchenPro',
            'sku': 'KP-RC-001',
            'image_url': 'images/products/rcc.jpg'
        },
        {
            'name': 'Treadmill',
            'description': 'NordicTrack treadmill with digital console, adjustable speed and incline. Features handlebars, multiple workout programs, and folding design for home fitness.',
            'price': 21999.99,
            'category': 'Sports & Fitness',
            'stock': 6,
            'brand': 'NordicTrack',
            'sku': 'CF-TM-001',
            'image_url': 'images/products/treadmill.jpg'
        },
        {
            'name': 'Pull-up Bar',
            'description': 'Wall-mounted pull-up bar with multiple grip positions. Features padded handles, neutral grips, and wide grip options. Perfect for upper body strength training.',
            'price': 1299.99,
            'category': 'Sports & Fitness',
            'stock': 30,
            'brand': 'PowerFit',
            'sku': 'PF-PB-001',
            'image_url': 'images/products/pullupbar.jpg'
        },
        {
            'name': 'Kettlebell Set',
            'description': 'Complete kettlebell set with two-tier rack. Includes 20 kettlebells ranging from 4KG to 42KG with color-coded bands. Perfect for comprehensive strength training.',
            'price': 4999.99,
            'category': 'Sports & Fitness',
            'stock': 12,
            'brand': 'PowerFit',
            'sku': 'PF-KS-001',
            'image_url': 'images/products/kettlebell.jpg'
        },
        {
            'name': 'Fitness Tracker',
            'description': 'Whoop fitness tracker with 24/7 wear capability and wireless charging. Features 99% accurate heart rate tracking, HRV monitoring, and personalized coaching insights.',
            'price': 2999.99,
            'category': 'Sports & Fitness',
            'stock': 45,
            'brand': 'Whoop',
            'sku': 'FL-FT-001',
            'image_url': 'images/products/fitnesstracker.jpg'
        },
        {
            'name': 'Medicine Ball',
            'description': 'Set of three black medicine balls with dimpled texture for better grip. Available in 4KG, 7KG, and 10KG weights. Perfect for strength training and core workouts.',
            'price': 1499.99,
            'category': 'Sports & Fitness',
            'stock': 25,
            'brand': 'PowerFit',
            'sku': 'PF-MB-001',
            'image_url': 'images/products/medicineball.jpg'
        },
    ]
    try:
        for product_data in sample_products:
            product = Product(**product_data)
            db.session.add(product)
        db.session.commit()
        flash(f'Successfully added {len(sample_products)} sample products!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding products: {str(e)}', 'error')
    return redirect(url_for('products'))


@app.route('/clear-products')
def clear_products():
    try:
        deleted_count = Product.query.delete()
        db.session.commit()
        flash(f'Successfully deleted {deleted_count} products from database.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error clearing products: {str(e)}', 'error')
    return redirect(url_for('products'))


@app.route('/cart')
@login_required
def cart():
    cart_items = Cart.query.filter_by(customer_id=current_user.id).all()
    total = sum(float(item.product.price) * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)


@app.route('/cart/add/<int:product_id>', methods=['POST'])
@login_required
def add_to_cart(product_id):
    product = Product.query.get_or_404(product_id)
    if not product.is_active or product.stock <= 0:
        flash('Product is not available.', 'error')
        return redirect(url_for('product_detail', product_id=product_id))
    quantity = int(request.form.get('quantity', 1))
    if quantity > product.stock:
        flash(f'Only {product.stock} items available in stock.', 'error')
        return redirect(url_for('product_detail', product_id=product_id))
    cart_item = Cart.query.filter_by(
        customer_id=current_user.id,
        product_id=product_id
    ).first()
    if cart_item:
        new_quantity = cart_item.quantity + quantity
        if new_quantity > product.stock:
            flash(f'Only {product.stock} items available in stock.', 'error')
            return redirect(url_for('product_detail', product_id=product_id))
        cart_item.quantity = new_quantity
    else:
        cart_item = Cart(
            customer_id=current_user.id,
            product_id=product_id,
            quantity=quantity
        )
        db.session.add(cart_item)
    db.session.commit()
    flash(f'{product.name} added to cart!', 'success')
    return redirect(url_for('cart'))


@app.route('/buy-now/<int:product_id>', methods=['POST'])
@login_required
def buy_now(product_id):
    product = Product.query.get_or_404(product_id)
    if not product.is_active or product.stock <= 0:
        flash('Product is not available.', 'error')
        return redirect(url_for('product_detail', product_id=product_id))
    quantity = int(request.form.get('quantity', 1))
    if quantity > product.stock:
        flash(f'Only {product.stock} items available in stock.', 'error')
        return redirect(url_for('product_detail', product_id=product_id))
    cart_item = Cart.query.filter_by(
        customer_id=current_user.id,
        product_id=product_id
    ).first()
    if cart_item:
        if quantity > product.stock:
            flash(f'Only {product.stock} items available in stock.', 'error')
            return redirect(url_for('product_detail', product_id=product_id))
        cart_item.quantity = quantity
    else:
        cart_item = Cart(
            customer_id=current_user.id,
            product_id=product_id,
            quantity=quantity
        )
        db.session.add(cart_item)
    db.session.commit()
    session['buy_now_product_id'] = product_id
    return redirect(url_for('checkout'))


@app.route('/cart/update/<int:cart_id>', methods=['POST'])
@login_required
def update_cart(cart_id):
    cart_item = Cart.query.get_or_404(cart_id)
    if cart_item.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('cart'))
    quantity = int(request.form.get('quantity', 1))
    if quantity <= 0:
        db.session.delete(cart_item)
        db.session.commit()
        flash('Item removed from cart.', 'info')
        return redirect(url_for('cart'))
    if quantity > cart_item.product.stock:
        flash(f'Only {cart_item.product.stock} items available in stock.', 'error')
        return redirect(url_for('cart'))
    cart_item.quantity = quantity
    db.session.commit()
    flash('Cart updated!', 'success')
    return redirect(url_for('cart'))


@app.route('/cart/remove/<int:cart_id>', methods=['POST'])
@login_required
def remove_from_cart(cart_id):
    cart_item = Cart.query.get_or_404(cart_id)
    if cart_item.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('cart'))
    db.session.delete(cart_item)
    db.session.commit()
    flash('Item removed from cart.', 'success')
    return redirect(url_for('cart'))


@app.route('/checkout', methods=['GET', 'POST'])
@login_required

def checkout():
    buy_now_product_id = session.get('buy_now_product_id')
    if buy_now_product_id:
        cart_items = Cart.query.filter_by(
            customer_id=current_user.id,
            product_id=buy_now_product_id
        ).all()
    else:
        cart_items = Cart.query.filter_by(customer_id=current_user.id).all()
    if not cart_items:
        session.pop('buy_now_product_id', None)
        flash('Your cart is empty.', 'error')
        return redirect(url_for('cart'))
    for item in cart_items:
        if item.quantity > item.product.stock:
            flash(f'{item.product.name} has insufficient stock.', 'error')
            return redirect(url_for('cart'))
        if request.method == 'POST':
            payment_method = request.form.get('payment_method')
            print(f"[CHECKOUT] Payment method received: {payment_method}")
            shipping_address = request.form.get('shipping_address')
            shipping_city = request.form.get('shipping_city')
            shipping_state = request.form.get('shipping_state', '')
            shipping_zip = request.form.get('shipping_zip', '')
            shipping_country = request.form.get('shipping_country', 'Philippines')
            print(f"[CHECKOUT] Address: {shipping_address}, City: {shipping_city}")
            if payment_method == 'credit_debit_card':
                card_number = request.form.get('card_number', '').strip()
                if not card_number:
                    flash('Please fill in all required fields.', 'error')
                    subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
                    return render_template('checkout.html', cart_items=cart_items, total=subtotal, customer=current_user)
            elif payment_method == 'gcash_payment':
                gcash_phone = request.form.get('gcash_phone', '').strip()
                gcash_name = request.form.get('gcash_name', '').strip()
                if not gcash_phone or not gcash_name:
                    flash('Please fill in all required fields.', 'error')
                    subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
                    return render_template('checkout.html', cart_items=cart_items, total=subtotal, customer=current_user)
            if not all([payment_method, shipping_address, shipping_city]):
                flash('Please fill in all required fields.', 'error')
                subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
                return render_template('checkout.html', cart_items=cart_items, total=subtotal, customer=current_user)
            subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
            shipping_fee = 8.00
            total = subtotal + shipping_fee
            try:
                order_number = f'ORD-{datetime.now().strftime("%Y%m%d")}-{current_user.id}-{Order.query.count() + 1}'
                if payment_method in ['gcash_payment', 'credit_debit_card']:
                    initial_payment_status = 'Paid'
                    initial_order_status = 'To Ship'
                elif payment_method == 'cash_on_delivery':
                    initial_payment_status = 'Pending'
                    initial_order_status = 'Pending'
                else:
                    initial_payment_status = 'Pending'
                    initial_order_status = 'Pending'
                print(f"[ORDER] Payment method: {payment_method}, Payment status: {initial_payment_status}, Order status: {initial_order_status}")
                order = Order(
                    order_number=order_number,
                    customer_id=current_user.id,
                    total_amount=total,
                    payment_method=payment_method,
                    payment_status=initial_payment_status,
                    shipping_address=shipping_address,
                    shipping_city=shipping_city,
                    shipping_state=shipping_state,
                    shipping_zip=shipping_zip,
                    shipping_country=shipping_country,
                    status=initial_order_status
                )
                db.session.add(order)
                db.session.flush()
                print(f"[ORDER] Creating order {order.order_number} for customer {current_user.id}")
                
                order_items_created = []
                for item in cart_items:
                    product = Product.query.get(item.product_id)
                    if not product:
                        raise ValueError(f'Product {item.product_id} not found')
                    if item.quantity > product.stock:
                        raise ValueError(f'Insufficient stock for {product.name}. Available: {product.stock}, Requested: {item.quantity}')
                    
                    order_item = OrderItem(
                        order_id=order.id,
                        product_id=item.product_id,
                        quantity=item.quantity,
                        price=product.price,
                        subtotal=float(product.price) * item.quantity
                    )
                    db.session.add(order_item)
                    order_items_created.append({
                        'product': product.name,
                        'quantity': item.quantity,
                        'price': float(product.price),
                        'subtotal': float(product.price) * item.quantity
                    })
                    print(f"[ORDER ITEM] Added {product.name} x{item.quantity} = ₱{float(product.price) * item.quantity:.2f}")
                    
                    product.stock -= item.quantity
                    if product.stock < 0:
                        product.stock = 0
                
                if payment_method == 'online_payment':
                    payment_status = 'Pending'
                elif payment_method == 'cash_on_delivery':
                    payment_status = 'Pending'
                else:
                    payment_status = 'Verified'
                payment = Payment(
                    order_id=order.id,
                    payment_method=payment_method,
                    amount=total,
                    status=payment_status
                )
                db.session.add(payment)
                print(f"[PAYMENT] Created payment record: {payment_method}, Status: {payment.status}")
                
                if current_user.order_updates:
                    notification = Notification(
                        customer_id=current_user.id,
                        order_id=order.id,
                        title='Order Placed',
                        message=f'Your order #{order.order_number} has been placed successfully. Total: ₱{total:.2f}',
                        type='order_created'
                    )
                    db.session.add(notification)
                
                for item in cart_items:
                    db.session.delete(item)
                
                session.pop('buy_now_product_id', None)
                
                db.session.commit()
                
                verified_order = Order.query.get(order.id)
                verified_items = OrderItem.query.filter_by(order_id=order.id).all()
                
                if not verified_order:
                    raise Exception("Order was not saved to database")
                if len(verified_items) != len(order_items_created):
                    raise Exception(f"Order items mismatch: Expected {len(order_items_created)}, Found {len(verified_items)}")
                
                print(f"[SUCCESS] Order {order.order_number} saved with {len(verified_items)} items")
                print(f"[SUCCESS] Order total: ₱{total:.2f}")
                print(f"[SUCCESS] Order ID: {order.id}, Order Number: {order.order_number}")
                print(f"[SUCCESS] Redirecting to My Purchase page...")
                
                try:
                    send_order_email(current_user, order, 'order_placed')
                except Exception as email_error:
                    print(f"Email sending failed (order still saved): {email_error}")
                
                if payment_method == 'credit_debit_card':
                    flash('Order placed successfully! Your card payment has been processed.', 'success')
                elif payment_method == 'gcash_payment':
                    flash('Order placed successfully! Your GCash payment has been processed.', 'success')
                elif payment_method == 'cash_on_delivery':
                    flash('Order placed successfully! You will pay when the order is delivered.', 'success')
                elif payment_method == 'online_payment':
                    flash('Order created! Please upload proof of payment from My Purchase page.', 'success')
                else:
                    flash('Order placed successfully!', 'success')
                
                return redirect(url_for('orders'))
            except Exception as e:
                db.session.rollback()
                import traceback
                error_details = traceback.format_exc()
                print(f"Order placement error: {error_details}")
                flash(f'An error occurred while processing your order: {str(e)}. Please try again.', 'error')
                subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
                return render_template('checkout.html', cart_items=cart_items, total=subtotal, customer=current_user)
    subtotal = sum(float(item.product.price) * item.quantity for item in cart_items)
    return render_template('checkout.html', cart_items=cart_items, total=subtotal, customer=current_user)


@app.route('/order/<int:order_id>/upload-payment', methods=['GET', 'POST'])
@login_required
def upload_payment(order_id):
    order = Order.query.get_or_404(order_id)
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    if order.payment_method not in ['online_payment', 'gcash_payment', 'credit_debit_card']:
        flash('This order does not require payment upload.', 'error')
        return redirect(url_for('order_detail', order_id=order.id))
    if request.method == 'POST':
        if 'proof_image' not in request.files:
            flash('No file selected.', 'error')
            return render_template('upload_payment.html', order=order)
        file = request.files['proof_image']
        if file.filename == '':
            flash('No file selected.', 'error')
            return render_template('upload_payment.html', order=order)
        if file and allowed_file(file.filename):
            filename = secure_filename(f'{order.order_number}_{datetime.now().strftime("%Y%m%d%H%M%S")}_{file.filename}')
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            payment = Payment.query.filter_by(order_id=order.id).first()
            if payment:
                payment.proof_image = f'uploads/payments/{filename}'
                payment.status = 'Pending'
                db.session.commit()
                flash('Proof of payment uploaded successfully! We will verify it soon.', 'success')
                return redirect(url_for('order_detail', order_id=order.id))
    return render_template('upload_payment.html', order=order)


def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/orders')
@login_required
def orders():
    status_filter = request.args.get('status', 'all')
    search_query = request.args.get('search', '').strip()
    query = Order.query.filter_by(customer_id=current_user.id)
    if status_filter == 'to_pay':
        query = query.filter(
            Order.status == 'Pending',
            Order.payment_status == 'Pending'
        )
    elif status_filter == 'to_ship':
        query = query.filter(
            db.or_(
                Order.status == 'To Ship',
                db.and_(
                    Order.status == 'Pending',
                    db.or_(
                        Order.payment_status == 'Paid',
                        Order.payment_status == 'Verified'
                    )
                )
            )
        )
    elif status_filter == 'to_receive':
        query = query.filter(Order.status == 'Shipped')
    elif status_filter == 'completed':
        query = query.filter(Order.status == 'Delivered')
    elif status_filter == 'cancelled':
        query = query.filter(Order.status == 'Cancelled')
    elif status_filter == 'all':
        query = query
    if search_query:
        query = query.join(OrderItem).join(Product).filter(
            db.or_(
                Order.order_number.ilike(f'%{search_query}%'),
                Product.name.ilike(f'%{search_query}%')
            )
        ).distinct()
    orders_list = query.order_by(Order.created_at.desc()).all()
    all_count = Order.query.filter_by(customer_id=current_user.id).count()
    to_pay_count = Order.query.filter_by(customer_id=current_user.id, status='Pending', payment_status='Pending').count()
    to_ship_count = Order.query.filter(
        Order.customer_id == current_user.id
    ).filter(
        db.or_(
            Order.status == 'To Ship',
            db.and_(
                Order.status == 'Pending',
                db.or_(Order.payment_status == 'Paid', Order.payment_status == 'Verified')
            )
        )
    ).count()
    to_receive_count = Order.query.filter_by(customer_id=current_user.id, status='Shipped').count()
    completed_count = Order.query.filter_by(customer_id=current_user.id, status='Delivered').count()
    cancelled_count = Order.query.filter_by(customer_id=current_user.id, status='Cancelled').count()
    return render_template('orders.html', 
                         orders=orders_list,
                         status_filter=status_filter,
                         search_query=search_query,
                         counts={
                             'all': all_count,
                             'to_pay': to_pay_count,
                             'to_ship': to_ship_count,
                             'to_receive': to_receive_count,
                             'completed': completed_count,
                             'cancelled': cancelled_count
                         })


@app.route('/orders/clear-cancelled', methods=['POST'])
@login_required
def clear_cancelled_orders():
    cancelled_orders = Order.query.filter_by(
        customer_id=current_user.id,
        status='Cancelled'
    ).all()
    for order in cancelled_orders:
        if order.payment:
            db.session.delete(order.payment)
        Notification.query.filter_by(order_id=order.id).delete()
        db.session.delete(order)
    db.session.commit()
    flash('All cancelled orders have been deleted.', 'success')
    return redirect(url_for('orders', status='cancelled'))


@app.route('/orders/cancel/<int:order_id>', methods=['POST'])
@login_required
def cancel_order(order_id):
    order = Order.query.get_or_404(order_id)
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    if order.status != 'Pending' or order.payment_status != 'Pending':
        flash('This order cannot be cancelled.', 'error')
        return redirect(url_for('orders'))
    for item in order.items:
        product = Product.query.get(item.product_id)
        if product:
            product.stock += item.quantity
    order.status = 'Cancelled'
    order.payment_status = 'Cancelled'
    if current_user.order_updates:
        notification = Notification(
            customer_id=current_user.id,
            order_id=order.id,
            title='Order Cancelled',
            message=f'Your order #{order.order_number} has been cancelled. Refund will be processed if applicable.',
            type='order_cancelled'
        )
        db.session.add(notification)
    db.session.commit()
    flash('Order cancelled successfully.', 'success')
    return redirect(url_for('orders', status='cancelled'))


@app.route('/order/<int:order_id>/buy-again', methods=['POST'])
@login_required
def buy_again(order_id):
    order = Order.query.get_or_404(order_id)
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    if order.status != 'Cancelled':
        flash('You can only buy again from cancelled orders.', 'error')
        return redirect(url_for('order_detail', order_id=order.id))
    items_added = 0
    items_skipped = []
    try:
        for order_item in order.items:
            product = Product.query.get(order_item.product_id)
            if not product:
                items_skipped.append('Unknown product (no longer available)')
                continue
            if not product.is_active:
                items_skipped.append(f'{product.name} (no longer available)')
                continue
            quantity_to_add = min(order_item.quantity, product.stock) if product.stock > 0 else 0
            if quantity_to_add == 0:
                items_skipped.append(f'{product.name} (out of stock)')
                continue
            cart_item = Cart.query.filter_by(
                customer_id=current_user.id,
                product_id=product.id
            ).first()
            if cart_item:
                new_quantity = cart_item.quantity + quantity_to_add
                if new_quantity > product.stock:
                    new_quantity = product.stock
                cart_item.quantity = new_quantity
            else:
                cart_item = Cart(
                    customer_id=current_user.id,
                    product_id=product.id,
                    quantity=quantity_to_add
                )
                db.session.add(cart_item)
            items_added += 1
        db.session.commit()
        if items_added > 0:
            flash(f'{items_added} item(s) added to cart successfully!', 'success')
        if items_skipped:
            flash(f'Some items could not be added: {", ".join(items_skipped)}', 'info')
        if items_added == 0:
            flash('No items could be added to cart. Products may be out of stock or no longer available.', 'error')
            return redirect(url_for('order_detail', order_id=order.id))
        return redirect(url_for('cart'))
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while adding items to cart. Please try again.', 'error')
        return redirect(url_for('order_detail', order_id=order.id))


@app.route('/order/<int:order_id>')
@login_required
def order_detail(order_id):
    order = Order.query.get_or_404(order_id)
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    if order.status == 'Pending' and order.payment_status == 'Pending':
        time_since_creation = datetime.utcnow() - order.created_at
        if time_since_creation.total_seconds() >= 60:
            order.payment_status = 'Paid'
            order.updated_at = datetime.utcnow()
            db.session.commit()
            if current_user.order_updates:
                notification = Notification(
                    customer_id=current_user.id,
                    order_id=order.id,
                    title='Order Processing',
                    message=f'Your order #{order.order_number} is now being prepared for shipment!',
                    type='order_processing'
                )
                db.session.add(notification)
                db.session.commit()
    payment = Payment.query.filter_by(order_id=order.id).first()
    return render_template('order_detail.html', order=order, payment=payment)


@app.route('/notification-settings', methods=['GET', 'POST'])
@login_required
def notification_settings():
    if request.method == 'POST':
        email_notifications = request.form.get('email_notifications') == 'on'
        order_updates = request.form.get('order_updates') == 'on'
        current_user.email_notifications = email_notifications
        current_user.order_updates = order_updates
        db.session.commit()
        flash('Notification settings updated successfully!', 'success')
        return redirect(url_for('notification_settings'))
    return render_template('notification_settings.html', 
customer=current_user)


@app.route('/notifications')
@login_required
def notifications():
    notifications_list = Notification.query.filter_by(customer_id=current_user.id).order_by(Notification.created_at.desc()).all()
    return render_template('notifications.html', notifications=notifications_list)


@app.route('/notifications/mark-read/<int:notification_id>', methods=['POST'])
@login_required
def mark_notification_read(notification_id):
    notification = Notification.query.get_or_404(notification_id)
    if notification.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('notifications'))
    notification.is_read = True
    db.session.commit()
    return redirect(url_for('notifications'))


@app.route('/notifications/clear-all', methods=['POST'])
@login_required
def clear_all_notifications():
    Notification.query.filter_by(customer_id=current_user.id).delete()
    db.session.commit()
    flash('All notifications cleared.', 'success')
    return redirect(url_for('notifications'))


@app.route('/notifications/delete/<int:notification_id>', methods=['POST'])
@login_required
def delete_notification(notification_id):
    notification = Notification.query.get_or_404(notification_id)
    if notification.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('notifications'))
    db.session.delete(notification)
    db.session.commit()
    flash('Notification deleted.', 'success')
    return redirect(url_for('notifications'))


@app.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        if not current_password or not new_password or not confirm_password:
            flash('All fields are required.', 'error')
            return render_template('change_password.html', customer=current_user)
        if not current_user.check_password(current_password):
            flash('Current password is incorrect.', 'error')
            return render_template('change_password.html', customer=current_user)
        if new_password != confirm_password:
            flash('New passwords do not match.', 'error')
            return render_template('change_password.html', customer=current_user)
        if len(new_password) < 6:
            flash('New password must be at least 6 characters long.', 'error')
            return render_template('change_password.html', customer=current_user)
        if current_user.check_password(new_password):
            flash('New password must be different from your current password.', 'error')
            return render_template('change_password.html', customer=current_user)
        try:
            current_user.set_password(new_password)
            db.session.commit()
            flash('Password changed successfully!', 'success')
            return redirect(url_for('profile'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while changing your password. Please try again.', 'error')
            return render_template('change_password.html', customer=current_user)
    return render_template('change_password.html', customer=current_user)


def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Access denied. Admin privileges required.', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/admin/dashboard')
@login_required
@admin_required
def admin_dashboard():
    from sqlalchemy import func
    total_orders = Order.query.count()
    total_customers = Customer.query.count()
    total_products = Product.query.count()
    total_revenue = db.session.query(func.sum(Order.total_amount)).filter(Order.payment_status == 'Paid').scalar() or 0
    
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(10).all()
    recent_customers = Customer.query.order_by(Customer.created_at.desc()).limit(10).all()
    
    return render_template('admin_dashboard.html',
                         total_orders=total_orders,
                         total_customers=total_customers,
                         total_products=total_products,
                         total_revenue=float(total_revenue),
                         recent_orders=recent_orders,
                         recent_customers=recent_customers)


@app.route('/admin/products')
@login_required
@admin_required
def admin_products():
    search = request.args.get('search', '').strip()
    category = request.args.get('category', '').strip()
    query = Product.query
    
    if search:
        query = query.filter(
            db.or_(
                Product.name.ilike(f'%{search}%'),
                Product.description.ilike(f'%{search}%'),
                Product.brand.ilike(f'%{search}%')
            )
        )
    if category:
        query = query.filter_by(category=category)
    
    products = query.order_by(Product.created_at.desc()).all()
    categories = db.session.query(Product.category).distinct().all()
    categories = [cat[0] for cat in categories if cat[0]]
    
    return render_template('admin_products.html', products=products, categories=categories, search=search, selected_category=category)

@app.route('/admin/products/add', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_add_product():
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        price = request.form.get('price')
        category = request.form.get('category')
        stock = request.form.get('stock', 0)
        brand = request.form.get('brand')
        sku = request.form.get('sku')
        image_url = request.form.get('image_url')
        
        if not name or not price or not category:
            flash('Name, price, and category are required.', 'error')
            return render_template('admin_product_form.html', product=None)
        
        try:
            price = float(price)
            stock = int(stock) if stock else 0
            
            product = Product(
                name=name,
                description=description,
                price=price,
                category=category,
                stock=stock,
                brand=brand,
                sku=sku,
                image_url=image_url or 'images/products/placeholder.jpg',
                is_active=True
            )
            db.session.add(product)
            db.session.commit()
            flash('Product added successfully!', 'success')
            return redirect(url_for('admin_products'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding product: {str(e)}', 'error')
    
    categories = db.session.query(Product.category).distinct().all()
    categories = [cat[0] for cat in categories if cat[0]]
    return render_template('admin_product_form.html', product=None, categories=categories)

@app.route('/admin/products/edit/<int:product_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    
    if request.method == 'POST':
        product.name = request.form.get('name')
        product.description = request.form.get('description')
        product.price = float(request.form.get('price'))
        product.category = request.form.get('category')
        product.stock = int(request.form.get('stock', 0))
        product.brand = request.form.get('brand')
        product.sku = request.form.get('sku')
        product.image_url = request.form.get('image_url') or product.image_url
        product.is_active = bool(request.form.get('is_active'))
        product.updated_at = datetime.utcnow()
        
        try:
            db.session.commit()
            flash('Product updated successfully!', 'success')
            return redirect(url_for('admin_products'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating product: {str(e)}', 'error')
    
    categories = db.session.query(Product.category).distinct().all()
    categories = [cat[0] for cat in categories if cat[0]]
    return render_template('admin_product_form.html', product=product, categories=categories)

@app.route('/admin/products/delete/<int:product_id>', methods=['POST'])
@login_required
@admin_required
def admin_delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    try:
        db.session.delete(product)
        db.session.commit()
        flash('Product deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting product: {str(e)}', 'error')
    return redirect(url_for('admin_products'))

@app.route('/admin/orders')
@login_required
@admin_required
def admin_orders():
    status_filter = request.args.get('status', 'all')
    search = request.args.get('search', '').strip()
    query = Order.query
    
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)
    
    if search:
        query = query.join(Customer).filter(
            db.or_(
                Order.order_number.ilike(f'%{search}%'),
                Customer.username.ilike(f'%{search}%'),
                Customer.email.ilike(f'%{search}%')
            )
        )
    
    orders = query.order_by(Order.created_at.desc()).all()
    return render_template('admin_orders.html', orders=orders, status_filter=status_filter, search=search)

@app.route('/admin/orders/<int:order_id>')
@login_required
@admin_required
def admin_order_detail(order_id):
    order = Order.query.get_or_404(order_id)
    return render_template('admin_order_detail.html', order=order)

@app.route('/admin/orders/<int:order_id>/approve', methods=['POST'])
@login_required
@admin_required
def admin_approve_order(order_id):
    order = Order.query.get_or_404(order_id)
    order.status = 'To Ship'
    if order.payment_status == 'Pending':
        order.payment_status = 'Verified'
    order.decline_reason = None
    order.updated_at = datetime.utcnow()
    
    try:
        db.session.commit()
        notification = Notification(
            customer_id=order.customer_id,
            order_id=order.id,
            title='Order Approved',
            message=f'Your order {order.order_number} has been approved and is being prepared for shipment.',
            type='order_update'
        )
        db.session.add(notification)
        db.session.commit()
        flash('Order approved successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error approving order: {str(e)}', 'error')
    
    return redirect(url_for('admin_order_detail', order_id=order_id))

@app.route('/admin/orders/<int:order_id>/decline', methods=['POST'])
@login_required
@admin_required
def admin_decline_order(order_id):
    order = Order.query.get_or_404(order_id)
    decline_reason = request.form.get('decline_reason', '').strip()
    
    if not decline_reason:
        flash('Please provide a reason for declining the order.', 'error')
        return redirect(url_for('admin_order_detail', order_id=order_id))
    
    order.status = 'Cancelled'
    order.decline_reason = decline_reason
    order.updated_at = datetime.utcnow()
    
    try:
        db.session.commit()
        notification = Notification(
            customer_id=order.customer_id,
            order_id=order.id,
            title='Order Declined',
            message=f'Your order {order.order_number} has been declined. Reason: {decline_reason}',
            type='order_update'
        )
        db.session.add(notification)
        db.session.commit()
        flash('Order declined successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error declining order: {str(e)}', 'error')
    
    return redirect(url_for('admin_order_detail', order_id=order_id))

@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    search = request.args.get('search', '').strip()
    query = Customer.query.filter(Customer.is_admin == False)
    
    if search:
        query = query.filter(
            db.or_(
                Customer.username.ilike(f'%{search}%'),
                Customer.email.ilike(f'%{search}%'),
                Customer.first_name.ilike(f'%{search}%'),
                Customer.last_name.ilike(f'%{search}%')
            )
        )
    
    users = query.order_by(Customer.created_at.desc()).all()
    return render_template('admin_users.html', users=users, search=search)

@app.route('/admin/users/<int:user_id>/reset-password', methods=['POST'])
@login_required
@admin_required
def admin_reset_user_password(user_id):
    user = Customer.query.get_or_404(user_id)
    if user.is_admin:
        flash('Cannot reset admin password.', 'error')
        return redirect(url_for('admin_users'))
    
    new_password = request.form.get('new_password', '').strip()
    if not new_password or len(new_password) < 6:
        flash('Password must be at least 6 characters long.', 'error')
        return redirect(url_for('admin_users'))
    
    try:
        user.set_password(new_password)
        db.session.commit()
        flash(f'Password reset successfully for {user.username}!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error resetting password: {str(e)}', 'error')
    
    return redirect(url_for('admin_users'))

@app.route('/admin/users/<int:user_id>/toggle-active', methods=['POST'])
@login_required
@admin_required
def admin_toggle_user_active(user_id):
    user = Customer.query.get_or_404(user_id)
    if user.is_admin:
        flash('Cannot deactivate admin account.', 'error')
        return redirect(url_for('admin_users'))
    
    try:
        user.is_active = not user.is_active
        db.session.commit()
        status = 'activated' if user.is_active else 'deactivated'
        flash(f'User {user.username} has been {status}.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating user status: {str(e)}', 'error')
    
    return redirect(url_for('admin_users'))

@app.route('/admin/reports')
@login_required
@admin_required
def admin_reports():
    period = request.args.get('period', 'daily')
    from sqlalchemy import func, extract
    
    today = datetime.utcnow().date()
    
    if period == 'daily':
        start_date = today
        end_date = today
        orders = Order.query.filter(func.date(Order.created_at) == today).all()
    elif period == 'weekly':
        start_date = today - timedelta(days=7)
        end_date = today
        orders = Order.query.filter(func.date(Order.created_at) >= start_date).all()
    elif period == 'monthly':
        start_date = today.replace(day=1)
        end_date = today
        orders = Order.query.filter(
            extract('year', Order.created_at) == today.year,
            extract('month', Order.created_at) == today.month
        ).all()
    else:
        orders = Order.query.all()
        start_date = None
        end_date = None
    
    total_orders = len(orders)
    total_revenue = sum(float(order.total_amount) for order in orders if order.payment_status == 'Paid')
    total_customers = len(set(order.customer_id for order in orders))
    
    return render_template('admin_reports.html', 
                         orders=orders,
                         period=period,
                         total_orders=total_orders,
                         total_revenue=total_revenue,
                         total_customers=total_customers,
                         start_date=start_date,
                         end_date=end_date)

@app.route('/admin/reports/export')
@login_required
@admin_required
def admin_export_report():
    period = request.args.get('period', 'daily')
    format_type = request.args.get('format', 'pdf')
    from sqlalchemy import func, extract
    
    today = datetime.utcnow().date()
    
    if period == 'daily':
        orders = Order.query.filter(func.date(Order.created_at) == today).all()
        period_label = f"Daily Report - {today.strftime('%Y-%m-%d')}"
    elif period == 'weekly':
        start_date = today - timedelta(days=7)
        orders = Order.query.filter(func.date(Order.created_at) >= start_date).all()
        period_label = f"Weekly Report - {start_date.strftime('%Y-%m-%d')} to {today.strftime('%Y-%m-%d')}"
    elif period == 'monthly':
        orders = Order.query.filter(
            extract('year', Order.created_at) == today.year,
            extract('month', Order.created_at) == today.month
        ).all()
        period_label = f"Monthly Report - {today.strftime('%B %Y')}"
    else:
        orders = Order.query.all()
        period_label = "All Time Report"
    
    total_revenue = sum(float(order.total_amount) for order in orders if order.payment_status == 'Paid')
    
    if format_type == 'pdf':
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        elements = []
        styles = getSampleStyleSheet()
        
        title = Paragraph(period_label, styles['Title'])
        elements.append(title)
        elements.append(Spacer(1, 12))
        
        summary_data = [
            ['Total Orders', str(len(orders))],
            ['Total Revenue', f'₱{total_revenue:.2f}'],
            ['Total Customers', str(len(set(order.customer_id for order in orders)))]
        ]
        summary_table = Table(summary_data)
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        elements.append(summary_table)
        elements.append(Spacer(1, 20))
        
        if orders:
            order_data = [['Order #', 'Customer', 'Amount', 'Status', 'Date']]
            for order in orders:
                order_data.append([
                    order.order_number,
                    f"{order.customer.first_name} {order.customer.last_name}",
                    f'₱{float(order.total_amount):.2f}',
                    order.status,
                    order.created_at.strftime('%Y-%m-%d')
                ])
            
            order_table = Table(order_data)
            order_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('FONTSIZE', (0, 1), (-1, -1), 10)
            ]))
            elements.append(order_table)
        
        doc.build(elements)
        buffer.seek(0)
        return send_file(buffer, mimetype='application/pdf', as_attachment=True, download_name=f'sales_report_{period}_{today.strftime("%Y%m%d")}.pdf')
    
    return redirect(url_for('admin_reports', period=period))

@app.route('/admin/categories')
@login_required
@admin_required
def admin_categories():
    from sqlalchemy import func
    categories = db.session.query(Product.category, func.count(Product.id).label('count'), func.sum(Product.stock).label('total_stock')).group_by(Product.category).all()
    category_data = [{'name': cat[0], 'product_count': cat[1], 'total_stock': int(cat[2] or 0)} for cat in categories]
    return render_template('admin_categories.html', categories=category_data)

@app.route('/admin/database')
@login_required
@admin_required
def admin_database():
    from sqlalchemy import inspect, func, text
    inspector = inspect(db.engine)
    
    tables = inspector.get_table_names()
    table_info = []
    
    for table_name in tables:
        columns = inspector.get_columns(table_name)
        row_count = db.session.execute(db.text(f'SELECT COUNT(*) FROM `{table_name}`')).scalar()
        
        table_info.append({
            'name': table_name,
            'columns': len(columns),
            'rows': row_count,
            'columns_detail': [{'name': col['name'], 'type': str(col['type'])} for col in columns]
        })
    
    admin_count = Customer.query.filter_by(is_admin=True).count()
    customer_count = Customer.query.filter_by(is_admin=False).count()
    
    db_stats = {
        'total_tables': len(tables),
        'total_customers': Customer.query.count(),
        'admin_users': admin_count,
        'regular_customers': customer_count,
        'total_products': Product.query.count(),
        'total_orders': Order.query.count(),
        'total_cart_items': Cart.query.count(),
        'total_payments': Payment.query.count(),
        'total_notifications': Notification.query.count(),
        'total_addresses': Address.query.count(),
    }
    
    db_connection_info = {
        'database_name': app.config['SQLALCHEMY_DATABASE_URI'].split('/')[-1].split('?')[0] if '/' in app.config['SQLALCHEMY_DATABASE_URI'] else 'N/A',
        'database_type': 'MySQL' if 'mysql' in app.config['SQLALCHEMY_DATABASE_URI'].lower() else 'SQLite',
        'connection_string': app.config['SQLALCHEMY_DATABASE_URI'].split('@')[-1] if '@' in app.config['SQLALCHEMY_DATABASE_URI'] else app.config['SQLALCHEMY_DATABASE_URI']
    }
    
    try:
        view_exists = db.session.execute(text("SHOW TABLES LIKE 'user_roles_view'")).fetchone()
        has_user_roles_view = view_exists is not None
    except:
        has_user_roles_view = False
    
    return render_template('admin_database.html', 
                         table_info=table_info,
                         db_stats=db_stats,
                         db_connection_info=db_connection_info,
                         has_user_roles_view=has_user_roles_view)

@app.route('/order/<int:order_id>/invoice')
@login_required
def download_invoice(order_id):
    order = Order.query.get_or_404(order_id)
    if order.customer_id != current_user.id:
        flash('Unauthorized access.', 'error')
        return redirect(url_for('orders'))
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
    elements = []
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#ff6b35'),
        spaceAfter=30,
        alignment=1
    )
    title = Paragraph("INVOICE", title_style)
    elements.append(title)
    elements.append(Spacer(1, 0.2*inch))
    company_info = f"""
    <b>ETR E-Commerce</b><br/>
    Email: {app.config['MAIL_DEFAULT_SENDER']}<br/>
    """
    
    customer_info = f"""
    <b>Bill To:</b><br/>
    {order.customer.first_name} {order.customer.last_name}<br/>
    {order.shipping_address}<br/>
    {order.shipping_city}, {order.shipping_state} {order.shipping_zip}<br/>
    {order.shipping_country}
    """
    info_table_data = [
        [Paragraph(company_info, styles['Normal']), Paragraph(customer_info, styles['Normal'])]
    ]
    info_table = Table(info_table_data, colWidths=[3*inch, 3*inch])
    info_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]))
    elements.append(info_table)
    elements.append(Spacer(1, 0.3*inch))
    order_details = f"""
    <b>Order Number:</b> {order.order_number}<br/>
    <b>Order Date:</b> {order.created_at.strftime('%B %d, %Y')}<br/>
    <b>Payment Method:</b> {order.payment_method.replace('_', ' ').title()}<br/>
    <b>Status:</b> {order.status}
    """
    elements.append(Paragraph(order_details, styles['Normal']))
    elements.append(Spacer(1, 0.3*inch))
    items_data = [['Item', 'Quantity', 'Unit Price', 'Total']]
    for item in order.items:
        items_data.append([
            item.product.name,
            str(item.quantity),
            f"₱{item.price:.2f}",
            f"₱{item.subtotal:.2f}"
        ])
    items_data.append(['', '', 'Subtotal:', f"₱{float(order.total_amount) - 8:.2f}"])
    items_data.append(['', '', 'Shipping Fee:', '₱8.00'])
    items_data.append(['', '', '<b>Total:</b>', f"<b>₱{order.total_amount:.2f}</b>"])
    items_table = Table(items_data, colWidths=[3*inch, 1*inch, 1.5*inch, 1.5*inch])
    items_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#ff6b35')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
        ('ALIGN', (2, 0), (-1, -1), 'RIGHT'),
        ('ALIGN', (3, 0), (-1, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -4), colors.beige),
        ('GRID', (0, 0), (-1, -4), 1, colors.grey),
        ('FONTNAME', (2, -3), (-1, -1), 'Helvetica-Bold'),
        ('TOPPADDING', (-2, -1), (-1, -1), 12),
        ('BOTTOMPADDING', (-2, -1), (-1, -1), 12),
    ]))
    elements.append(items_table)
    doc.build(elements)
    buffer.seek(0)
    filename = f'invoice_{order.order_number}.pdf'
    return send_file(buffer, as_attachment=True, download_name=filename, mimetype='application/pdf')


def send_order_email(customer, order, email_type='order_placed'):
    if not customer.email_notifications and email_type != 'payment_required':
        return
    try:
        if email_type == 'order_placed':
            subject = f'Order Confirmation - {order.order_number}'
            template = 'emails/order_placed.html'
        elif email_type == 'order_shipped':
            subject = f'Your Order Has Shipped - {order.order_number}'
            template = 'emails/order_shipped.html'
        elif email_type == 'order_delivered':
            subject = f'Order Delivered - {order.order_number}'
            template = 'emails/order_delivered.html'
        elif email_type == 'payment_verified':
            subject = f'Payment Verified - {order.order_number}'
            template = 'emails/payment_verified.html'
        else:
            return
        msg = Message(
            subject=subject,
            recipients=[customer.email],
            html=render_template(template, customer=customer, order=order)
        )
        if not app.config['MAIL_SUPPRESS_SEND']:
            mail.send(msg)
    except Exception as e:
        pass


if __name__ == '__main__':
    with app.app_context():
        try:
            db.create_all()
            print("Database connection successful! Tables created/verified.")
        except Exception as e:
            error_str = str(e)
            if "Unknown database" in error_str or "1049" in error_str:
                print("\n" + "="*60)
                print("Database 'etr_ecommerce' does not exist!")
                print("="*60)
                print("\nCreating database automatically...")
                try:
                    import pymysql
                    mysql_user = os.environ.get('MYSQL_USER', 'root')
                    mysql_password = os.environ.get('MYSQL_PASSWORD', '')
                    mysql_host = os.environ.get('MYSQL_HOST', 'localhost')
                    mysql_port = int(os.environ.get('MYSQL_PORT', '3306'))
                    mysql_db = os.environ.get('MYSQL_DATABASE', 'etr_ecommerce')
                    
                    if mysql_password:
                        conn = pymysql.connect(host=mysql_host, port=mysql_port, user=mysql_user, password=mysql_password)
                    else:
                        conn = pymysql.connect(host=mysql_host, port=mysql_port, user=mysql_user)
                    
                    with conn.cursor() as cursor:
                        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {mysql_db} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
                    conn.close()
                    print(f"✓ Database '{mysql_db}' created successfully!")
                    print("\nCreating tables...")
                    db.create_all()
                    print("✓ Tables created successfully!")
                except Exception as create_error:
                    print(f"\n✗ Failed to create database automatically: {create_error}")
                    print("\nPlease create the database manually:")
                    print("1. Open phpMyAdmin: http://localhost/phpmyadmin")
                    print("2. Click 'New' in the left sidebar")
                    print("3. Database name: etr_ecommerce")
                    print("4. Collation: utf8mb4_unicode_ci")
                    print("5. Click 'Create'")
                    print("\nOr run in MySQL command line:")
                    print("CREATE DATABASE etr_ecommerce CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
                    exit(1)
            else:
                print("\n" + "="*60)
                print("ERROR: Cannot connect to MySQL database!")
                print("="*60)
                print(f"\nError details: {e}")
                print("\nPlease ensure:")
                print("1. MySQL server is running")
                print("2. MySQL credentials in app.py are correct")
                print("\nTo start MySQL:")
                print("- If using XAMPP: Start MySQL from XAMPP Control Panel")
                print("- If using WAMP: Start MySQL from WAMP Control Panel")
                print("- If installed separately: Start MySQL service")
                print("\n" + "-"*60)
                print("TEMPORARY SOLUTION: Use SQLite while setting up MySQL")
                print("-"*60)
                print("Set environment variable: USE_MYSQL=false")
                print("Or run: $env:USE_MYSQL='false'; python app.py")
                print("="*60 + "\n")
                exit(1)
    app.run(debug=True)

