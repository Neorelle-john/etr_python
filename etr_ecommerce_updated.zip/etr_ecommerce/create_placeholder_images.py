import os
import shutil
import re

static_path = 'static/images/products'
app_file = 'app.py'
placeholder = 'placeholder.jpg'

if not os.path.exists(os.path.join(static_path, placeholder)):
    print(f"ERROR: {placeholder} not found in {static_path}")
    exit(1)

existing_images = set()
if os.path.exists(static_path):
    for file in os.listdir(static_path):
        if file.endswith('.jpg') or file.endswith('.png'):
            existing_images.add(file)

with open(app_file, 'r', encoding='utf-8') as f:
    content = f.read()

pattern = r"'image_url':\s*'images/products/([^']+)'"
matches = re.findall(pattern, content)
referenced_images = set(matches)

missing_images = referenced_images - existing_images

if not missing_images:
    print("All images exist! No placeholders needed.")
    exit(0)

print(f"Creating {len(missing_images)} placeholder images...")
print("-" * 60)

placeholder_path = os.path.join(static_path, placeholder)
created_count = 0

for img in sorted(missing_images):
    target_path = os.path.join(static_path, img)
    try:
        shutil.copy2(placeholder_path, target_path)
        print(f"[OK] Created: {img}")
        created_count += 1
    except Exception as e:
        print(f"[ERROR] Failed to create {img}: {e}")

print("-" * 60)
print(f"Successfully created {created_count} placeholder images!")
print(f"\nNow all products will show images (placeholders).")
print(f"Replace these placeholder files with your actual product images when ready.")

