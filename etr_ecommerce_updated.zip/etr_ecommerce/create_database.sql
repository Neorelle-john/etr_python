CREATE DATABASE IF NOT EXISTS etr_ecommerce CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

