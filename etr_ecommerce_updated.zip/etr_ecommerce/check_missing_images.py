import os
import re

static_path = 'static/images/products'
app_file = 'app.py'

existing_images = set()
if os.path.exists(static_path):
    for file in os.listdir(static_path):
        if file.endswith('.jpg') or file.endswith('.png'):
            existing_images.add(file)

print("Existing images in static/images/products/:")
print(f"Total: {len(existing_images)}")
for img in sorted(existing_images):
    print(f"  - {img}")

print("\n" + "="*60)
print("Checking app.py for referenced images...")
print("="*60)

with open(app_file, 'r', encoding='utf-8') as f:
    content = f.read()

pattern = r"'image_url':\s*'images/products/([^']+)'"
matches = re.findall(pattern, content)
referenced_images = set(matches)

print(f"\nTotal images referenced in code: {len(referenced_images)}")

missing_images = referenced_images - existing_images
existing_refs = referenced_images & existing_images

print(f"\n[OK] Images that exist: {len(existing_refs)}")
print(f"[MISSING] Images that are MISSING: {len(missing_images)}")

if missing_images:
    print("\nMISSING IMAGES (need to be added):")
    print("-" * 60)
    for img in sorted(missing_images):
        print(f"  [X] {img}")

if existing_refs:
    print(f"\n\nEXISTING IMAGES (already in folder):")
    print("-" * 60)
    for img in sorted(existing_refs):
        print(f"  [OK] {img}")

print("\n" + "="*60)
print("SOLUTION:")
print("="*60)
print("1. Copy your product images to: static/images/products/")
print("2. Make sure filenames match exactly (case-sensitive)")
print("3. Or use placeholder.jpg temporarily by copying it:")
print(f"   copy {static_path}/placeholder.jpg {static_path}/[missing_filename]")

