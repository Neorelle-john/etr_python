from app import app, db
from sqlalchemy import text

with app.app_context():
    try:
        print("Creating database view for user roles...")
        
        view_sql = """
        CREATE OR REPLACE VIEW user_roles_view AS
        SELECT 
            id,
            username,
            email,
            first_name,
            last_name,
            CASE 
                WHEN is_admin = 1 THEN 'Admin'
                ELSE 'Customer'
            END AS user_role,
            is_admin,
            is_active,
            created_at
        FROM customer
        ORDER BY is_admin DESC, created_at DESC;
        """
        
        db.session.execute(text(view_sql))
        db.session.commit()
        print("[SUCCESS] Created 'user_roles_view' - View all users with their roles")
        print("  - Access in phpMyAdmin: Look for 'user_roles_view' in the left sidebar")
        print("  - Admin users will show 'Admin' in the user_role column")
        print("  - Customer users will show 'Customer' in the user_role column")
        
        print("\nAdding database comments to customer table...")
        comment_sql = """
        ALTER TABLE customer 
        COMMENT = 'Customer table - Contains both customers and admin users. Check is_admin column (1=Admin, 0=Customer)';
        """
        db.session.execute(text(comment_sql))
        db.session.commit()
        print("[SUCCESS] Added table comment to customer table")
        
        print("\n" + "="*70)
        print("DATABASE LABELS ADDED SUCCESSFULLY!")
        print("="*70)
        print("\nIn phpMyAdmin, you can now:")
        print("1. View 'user_roles_view' to see all users with their roles labeled")
        print("2. Check the 'customer' table - the is_admin column shows:")
        print("   - 1 (or TRUE) = Admin")
        print("   - 0 (or FALSE) = Customer")
        print("3. The table has a comment explaining the is_admin column")
        print("\n" + "="*70)
        
    except Exception as e:
        db.session.rollback()
        print(f"[ERROR] Failed to create view: {e}")
        print("\nTrying alternative method...")
        
        try:
            view_sql_simple = """
            CREATE VIEW IF NOT EXISTS user_roles_view AS
            SELECT 
                id,
                username,
                email,
                first_name,
                last_name,
                IF(is_admin = 1, 'Admin', 'Customer') AS user_role,
                is_admin,
                is_active,
                created_at
            FROM customer
            ORDER BY is_admin DESC, created_at DESC;
            """
            db.session.execute(text(view_sql_simple))
            db.session.commit()
            print("[SUCCESS] Created view using alternative method")
        except Exception as e2:
            print(f"[ERROR] Alternative method also failed: {e2}")

